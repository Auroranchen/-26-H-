/*
 * ========================== icm42688.c ==========================
 *  汇电籽-601 姿态模块串口驱动实现。
 *  详细协议、接线与用法见 icm42688.h 头部注释。
 *
 *  实现要点：
 *      - 发送指令: 初始化阶段用阻塞发送(一次性, 无所谓阻塞)。
 *      - 接收解析: 在 UART2 中断里做“帧头对齐 + 定长收帧 + 校验”状态机,
 *                  收满一帧且校验通过就解析出姿态角并置“已更新”标志。
 *      - 主循环通过 ICM42688_IsUpdated()/GetAttitude() 非阻塞取数据。
 * ===============================================================
 */
#include "icm42688.h"
#include "delay.h"
#include "oled.h"

/* ---- 协议常量 ---- */
#define IMU_HEAD1       0xAA
#define IMU_HEAD2       0x55
#define IMU_DEV_ID      0x60
#define IMU_FRAME_LEN   12      /* 仅姿态模式整帧长度: AA 55 60 01 06 [6字节] CS */

/* ---- 接收状态机所用的私有变量(static, 不对外暴露) ---- */
static uint8_t  s_rx_buf[IMU_FRAME_LEN];    /* 收帧缓冲 */
static uint8_t  s_rx_idx      = 0;          /* 当前写入位置 */
static uint8_t  s_last_byte   = 0;          /* 上一个字节(用于识别帧头 AA 55) */

/* ---- 解析结果 + 非阻塞更新标志 ---- */
static volatile Attitude_t s_attitude   = {0};
static volatile uint8_t    s_updated    = 0;    /* 1=有新帧待读取 */

/* 向模块阻塞发送一串字节(仅初始化下发指令用) */
static void imu_send(const uint8_t *buf, uint16_t len)
{
    for (uint16_t i = 0; i < len; i++) {
        DL_UART_Main_transmitDataBlocking(UART_2_INST, buf[i]);
    }
}

/* 校验并解析一整帧(已确认帧头/长度正确, 只差校验和) */
static void imu_parse_frame(void)
{
    /* 校验和: 从 DevID(下标2) 累加到 DATA 结束(下标10), 与 CS(下标11) 比较 */
    uint8_t cs = 0;
    for (uint8_t i = 2; i < IMU_FRAME_LEN - 1; i++) {
        cs += s_rx_buf[i];
    }
    if (cs != s_rx_buf[IMU_FRAME_LEN - 1]) {
        return;     /* 校验失败, 丢弃 */
    }

    /* DATA 区从下标5开始: [Yaw(u16), Pitch(i16), Roll(i16)], 小端, 放大100倍 */
    uint16_t yaw_raw   = (uint16_t)(s_rx_buf[5] | (s_rx_buf[6]  << 8));
    int16_t  pitch_raw = (int16_t) (s_rx_buf[7] | (s_rx_buf[8]  << 8));
    int16_t  roll_raw  = (int16_t) (s_rx_buf[9] | (s_rx_buf[10] << 8));

    s_attitude.yaw   = yaw_raw   / 100.0f;
    s_attitude.pitch = pitch_raw / 100.0f;
    s_attitude.roll  = roll_raw  / 100.0f;
    s_updated = 1;      /* 通知主循环: 有新数据 */
}

void ICM42688_Init(void)
{
    /* 1. 软复位模块, 等它重启 */
    uint8_t cmd_reset[] = {0xAA, 0x55, 0x60, 0x12, 0x00, 0x72};
    imu_send(cmd_reset, sizeof(cmd_reset));
    Delay_Ms(500);

    /* 2. 设为“仅姿态模式”(LEN=6): AA 55 60 0B 01 01 6D */
    uint8_t cmd_mode[] = {0xAA, 0x55, 0x60, 0x0B, 0x01, 0x01, 0x6D};
    imu_send(cmd_mode, sizeof(cmd_mode));
    Delay_Ms(20);

    /* 3. 启动数据上报: AA 55 60 0A 01 01 6C */
    uint8_t cmd_start[] = {0xAA, 0x55, 0x60, 0x0A, 0x01, 0x01, 0x6C};
    imu_send(cmd_start, sizeof(cmd_start));

    /* 4. 复位收帧状态机, 打开 NVIC 接收中断
     *    (外设级 RX 中断已在 SysConfig 的 UART_2 里使能) */
    s_rx_idx    = 0;
    s_last_byte = 0;
    s_updated   = 0;
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
}

uint8_t ICM42688_IsUpdated(void)
{
    return s_updated;
}

/* 触发模块重新校准。协议 0x10 指令(无数据区): AA 55 60 10 00 70
 * CS = (0x60+0x10+0x00) & 0xFF = 0x70。 */
void ICM42688_Calibrate(void)
{
    uint8_t cmd_calib[] = {0xAA, 0x55, 0x60, 0x10, 0x00, 0x70};
    imu_send(cmd_calib, sizeof(cmd_calib));
}

void ICM42688_GetAttitude(Attitude_t *out)
{
    if (out == NULL) return;
    /* 关中断读取, 避免读一半被新帧改写(临界区保护) */
    NVIC_DisableIRQ(UART_2_INST_INT_IRQN);
    out->yaw   = s_attitude.yaw;
    out->pitch = s_attitude.pitch;
    out->roll  = s_attitude.roll;
    s_updated  = 0;
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
}

/* 在 OLED 上显示一个带正负号、两位小数的角度值。
 * 例如 -12.34 显示为 "-012.34"(整数补足3位, 便于对齐)。 */
static void oled_show_angle(uint8_t x, uint8_t y, float val)
{
    uint8_t neg = 0;
    if (val < 0) { neg = 1; val = -val; }

    uint32_t scaled = (uint32_t)(val * 100.0f + 0.5f);  /* 放大100取整, 含四舍五入 */
    uint32_t ipart  = scaled / 100;                      /* 整数部分 */
    uint32_t fpart  = scaled % 100;                      /* 两位小数 */

    /* 正负号 */
    OLED_ShowChar(x, y, neg ? '-' : '+', 16);
    /* 整数部分(补足3位) + 小数点 + 两位小数 */
    OLED_ShowNum(x + 8,  y, ipart, 3, 16);
    OLED_ShowChar(x + 32, y, '.', 16);
    OLED_ShowNum(x + 40, y, fpart, 2, 16);
}

void ICM42688_ShowOnOLED(uint8_t x, uint8_t y)
{
    Attitude_t att;
    ICM42688_GetAttitude(&att);

    OLED_ShowString(x, y,      (u8 *)"Y:", 16);
    oled_show_angle(x + 24, y,      att.yaw);
    OLED_ShowString(x, y + 16, (u8 *)"P:", 16);
    oled_show_angle(x + 24, y + 16, att.pitch);
    OLED_ShowString(x, y + 32, (u8 *)"R:", 16);
    oled_show_angle(x + 24, y + 32, att.roll);
}

/* ---------- UART2 接收中断: 逐字节收帧 ----------
 * 函数名 UART_2_INST_IRQHandler 由 SysConfig 生成(见 ti_msp_dl_config.h)。 */
void UART_2_INST_IRQHandler(void)
{
    switch (DL_UART_getPendingInterrupt(UART_2_INST)) {
        case DL_UART_IIDX_RX: {
            uint8_t byte = DL_UART_Main_receiveData(UART_2_INST);

            /* 检测帧头 AA 55: 一旦出现就把它作为新帧起点, 抗错位 */
            if (s_last_byte == IMU_HEAD1 && byte == IMU_HEAD2) {
                s_rx_buf[0] = IMU_HEAD1;
                s_rx_buf[1] = IMU_HEAD2;
                s_rx_idx    = 2;
                s_last_byte = byte;
                break;
            }
            s_last_byte = byte;

            /* 未对齐到帧头前, 丢弃 */
            if (s_rx_idx == 0) {
                break;
            }

            /* 正常存字节 */
            if (s_rx_idx < IMU_FRAME_LEN) {
                s_rx_buf[s_rx_idx++] = byte;
            }

            /* 收满一整帧 -> 解析 */
            if (s_rx_idx >= IMU_FRAME_LEN) {
                imu_parse_frame();
                s_rx_idx = 0;       /* 复位, 等下一帧的帧头 */
            }
            break;
        }

        case DL_UART_IIDX_OVERRUN_ERROR:
            /* 溢出: 复位状态机, 丢掉当前半帧, 等下一个帧头重新同步 */
            s_rx_idx = 0;
            break;

        default:
            break;
    }
}
