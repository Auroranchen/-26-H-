/*
 * ========================== vl53l0x.h ==========================
 *  简介：
 *      ST VL53L0X 激光 ToF 测距传感器驱动封装（I2C）。
 *      提供：上电复位(XSHUT)、初始化、连续测距启动、读取距离(mm)。
 *
 *  硬件接线 (MSPM0G3507, 由 SysConfig 配置)：
 *      SCL  -> GPIOA.1    (I2C0_SCL, SysConfig 名 Steering)
 *      SDA  -> GPIOA.0    (I2C0_SDA)
 *      XSHUT-> GPIOB.8    (SysConfig 引脚组 VL53L0_EN, 软件控制)
 *      GPIO1 未使用
 *      VCC  -> 3.3V       GND -> GND
 *      默认 I2C 地址 0x29 (7-bit)
 *
 *  使用方法：
 *      1. 包含头文件：
 *              #include "vl53l0x.h"
 *
 *      2. 上电后先芯片初始化, 再初始化传感器：
 *              SYSCFG_DL_init();
 *              Delay_TimerStart();     // 若用非阻塞定时可选
 *              if (!VL53L0X_Init()) {
 *                  // 初始化失败: 检查接线/供电/XSHUT
 *              }
 *              VL53L0X_StartContinuous(0);  // 0=尽可能快连续测距
 *
 *      3. 主循环或控制环里读取距离(单位 mm, 超时/失败返回 0xFFFF)：
 *              uint16_t dist = VL53L0X_ReadRangeContinuousMillimeters();
 *              // dist 有效范围约 30~2000 mm(视模式与环境)
 *
 *  依赖：
 *      - delay.h / delay.c   (初始化固定等待)
 *      - I2C0 (SysConfig 名 Steering, 已使能 Controller)
 *      - GPIO 组 VL53L0_EN (XSHUT)
 * ===============================================================
 */
#ifndef VL53L0X_H
#define VL53L0X_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 默认 7-bit I2C 地址 */
#define VL53L0X_I2C_ADDR        0x29

/* 读距失败/超时返回值 */
#define VL53L0X_RANGE_ERROR     0xFFFF

/*
 * VL53L0X_Init - 通过 XSHUT 复位并完成传感器初始化(含基础校准配置)。
 *                返回 1=成功, 0=失败(ID 不对或通信异常)。
 *
 * VL53L0X_StartContinuous - 启动连续测距。
 *                period_ms: 测距周期(ms), 0 表示尽可能快。
 *
 * VL53L0X_StopContinuous - 停止连续测距。
 *
 * VL53L0X_ReadRangeContinuousMillimeters - 读取一次连续测距结果(mm)。
 *                阻塞等待数据就绪(内部有超时)。失败返回 VL53L0X_RANGE_ERROR。
 *
 * VL53L0X_SetTimeout - 设置单次读距最大等待时间(ms), 默认 500。
 *
 * VL53L0X_GetAddress / VL53L0X_SetAddress - 获取/修改当前 I2C 地址
 *                (多传感器时在 Init 后改地址再 Init 下一颗)。
 */
uint8_t  VL53L0X_Init(void);
void     VL53L0X_StartContinuous(uint32_t period_ms);
void     VL53L0X_StopContinuous(void);
uint16_t VL53L0X_ReadRangeContinuousMillimeters(void);
void     VL53L0X_SetTimeout(uint16_t timeout_ms);
uint8_t  VL53L0X_GetAddress(void);
void     VL53L0X_SetAddress(uint8_t new_addr);

#ifdef __cplusplus
}
#endif

#endif /* VL53L0X_H */
