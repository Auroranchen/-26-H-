/*
 * ======================= CarStateSend.h =======================
 *  USART2 发送运动状态与摆球模式报文。
 *
 *  协议(定长 5 字节)：
 *      0x5A [state] [modenum] [checksum] 0xA5
 *      checksum = state ^ modenum
 * ==============================================================
 */
#ifndef __CARSTATE_SEND_H
#define __CARSTATE_SEND_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 3507 运动状态(state 字节)。 */
typedef enum {
    CARSTATE_SEND_MOTION_STOP  = 0,
    CARSTATE_SEND_MOTION_START = 1,
    CARSTATE_SEND_MOTION_RUN   = 2,
    CARSTATE_SEND_MOTION_TURN  = 3,
    CARSTATE_SEND_MOTION_BRAKE = 4
} CarStateSendMotionState;

/* 摆球模式(mode 字节)。注意：协议模式号不等于 EVENT 编号。 */
typedef enum {
    CARSTATE_SEND_MODE_IDLE   = 0,
    CARSTATE_SEND_MODE_EVENT3 = 1,
    CARSTATE_SEND_MODE_EVENT4 = 2,
    CARSTATE_SEND_MODE_EVENT5 = 3,
    CARSTATE_SEND_MODE_EVENT6 = 4
} CarStateSendMode;

/*
 * 初始化发送模块。
 * 当前使用阻塞式 HAL UART 发送，无需额外初始化。
 */
void CarStateSend_Init(void);

/*
 * 通过 USART2 发送一帧报文。
 *      state : CarStateSendMotionState，运动状态编号 0~4
 *      mode  : CarStateSendMode，摆球模式号 0~4
 * 返回：true=参数合法且本地 UART 已发送完毕，false=参数无效。
 * 注意：true 不表示 STM32 已收到报文或已完成摆球动作。
 */
bool CarStateSend_Send(uint8_t state, uint8_t mode);

#ifdef __cplusplus
}
#endif

#endif
