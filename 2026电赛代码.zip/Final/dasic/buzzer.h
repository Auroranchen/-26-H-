/*
 * =========================== buzzer.h ===========================
 *  简介：
 *      有源蜂鸣器驱动封装。
 *      “有源”= 内部自带振荡源, 只要给它有效电平就会响, 不用输出方波。
 *      本板蜂鸣器为【低电平触发】: 引脚拉低 -> 响, 拉高 -> 停。
 *
 *  硬件接线 (MSPM0G3507, 由 SysConfig 配置)：
 *      BUZZER -> GPIOA.14   (PINCM36)
 *      默认上电为高电平(不响), 与低电平触发匹配。
 *
 *  使用方法：
 *      1. 包含头文件：
 *              #include "buzzer.h"
 *              #include "delay.h"   // 用到 Beep() 短鸣时需要
 *
 *      2. 上电后先做芯片初始化(引脚已在此初始化好, 无需再配)：
 *              SYSCFG_DL_init();
 *
 *      3. 直接调用：
 *              Buzzer_On();        // 一直响
 *              Buzzer_Off();       // 停止
 *              Buzzer_Toggle();    // 响/停 翻转
 *              Beep(100);          // 响 100 毫秒后自动停(阻塞)
 *
 *  依赖：
 *      - Beep() 用到 delay.h / delay.c 里的 Delay_Ms()
 * ===============================================================
 */
#ifndef BUZZER_H
#define BUZZER_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Buzzer_On     - 蜂鸣器开始鸣叫(引脚拉低)
 * Buzzer_Off    - 蜂鸣器停止(引脚拉高)
 * Buzzer_Toggle - 翻转当前鸣叫状态
 * Beep(ms)      - 鸣叫指定毫秒数后自动停止(阻塞, 依赖 Delay_Ms)
 */
void Buzzer_On(void);
void Buzzer_Off(void);
void Buzzer_Toggle(void);
void Beep(uint32_t ms);

#ifdef __cplusplus
}
#endif

#endif /* BUZZER_H */
