/*
 * =========================== delay.c ===========================
 *  两类延时实现：
 *    1) 基于 CPU 主频的阻塞式死等 (Delay_Us / Delay_Ms / Delay_S)
 *    2) 基于 TIMER_1 (TIMA1) 1ms 节拍的系统计时
 *       (Delay_TimerStart / Delay_GetTick / Delay_TimerMs)
 *  详细使用说明见 delay.h 头部注释。
 * ===============================================================
 */
#include "delay.h"

/* ================= 一、CPU 主频死等 ================= */

/* 每微秒/毫秒对应的 CPU cycle 数, 由主频 CPUCLK_FREQ 换算而来。
 * 本板 CPUCLK_FREQ = 80000000 -> 每微秒 80 个 cycle。 */
#define CYCLES_PER_US   (CPUCLK_FREQ / 1000000UL)
#define CYCLES_PER_MS   (CPUCLK_FREQ / 1000UL)

void Delay_Us(uint32_t us)
{
    while (us--) {
        delay_cycles(CYCLES_PER_US);
    }
}

void Delay_Ms(uint32_t ms)
{
    while (ms--) {
        delay_cycles(CYCLES_PER_MS);
    }
}

void Delay_S(uint32_t s)
{
    while (s--) {
        Delay_Ms(1000);
    }
}

/* ================= 二、TIMER_1 1ms 系统节拍 ================= */

/* 系统运行毫秒计数。TIMER_1 每 1ms 触发一次中断, 在此 +1。
 * 用 volatile 保证主循环读到的是中断里最新写入的值。 */
static volatile uint32_t g_tick_ms = 0;

/* TIMER_1 (TIMA1) 中断服务函数。
 * 函数名 TIMER_1_INST_IRQHandler 由 SysConfig 生成(见 ti_msp_dl_config.h)。 */
void TIMER_1_INST_IRQHandler(void)
{
    /* 读取并清除中断标志; 是零事件(计到0重装)则记一个毫秒 */
    switch (DL_TimerA_getPendingInterrupt(TIMER_1_INST)) {
        case DL_TIMERA_IIDX_ZERO:
            g_tick_ms++;
            break;
        default:
            break;
    }
}

void Delay_TimerStart(void)
{
    /* SysConfig 已配好 TIMER_1 为 1ms 周期并使能了外设级中断,
     * 这里只需在 NVIC 打开该中断, 计时即开始。 */
    NVIC_EnableIRQ(TIMER_1_INST_INT_IRQN);
}

uint32_t Delay_GetTick(void)
{
    return g_tick_ms;
}

void Delay_TimerMs(uint32_t ms)
{
    uint32_t start = g_tick_ms;
    /* 无符号相减天然处理计数溢出回绕 */
    while ((g_tick_ms - start) < ms) {
        /* 等待节拍累加; 期间可换成低功耗等待 */
    }
}
