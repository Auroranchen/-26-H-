################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/2026-Ti-Competitive/Final/dasic" -I"D:/2026-Ti-Competitive/Final/dasic/Debug" -I"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-1244724463: ../empty.syscfg
	@echo 'SysConfig - building file: "$<"'
	"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/sysconfig_1.26.2/sysconfig_cli.bat" -s "D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/.metadata/product.json" --script "D:/2026-Ti-Competitive/Final/dasic/empty.syscfg" -o "." --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

device_linker.cmd: build-1244724463 ../empty.syscfg
device.opt: build-1244724463
device.cmd.genlibs: build-1244724463
ti_msp_dl_config.c: build-1244724463
ti_msp_dl_config.h: build-1244724463
Event.dot: build-1244724463

%.o: ./%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/2026-Ti-Competitive/Final/dasic" -I"D:/2026-Ti-Competitive/Final/dasic/Debug" -I"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/2026-Ti-Competitive/Final/dasic" -I"D:/2026-Ti-Competitive/Final/dasic/Debug" -I"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source" -g -Wall -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


