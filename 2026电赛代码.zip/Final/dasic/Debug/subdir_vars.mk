################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../CarStateSend.c \
../bmi088.c \
../buzzer.c \
../control.c \
../delay.c \
./ti_msp_dl_config.c \
D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../gray.c \
../icm42688.c \
../key.c \
../led.c \
../main.c \
../motor.c \
../oled.c \
../pca9685.c \
../qd4310.c \
../vl53l0x.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./CarStateSend.d \
./bmi088.d \
./buzzer.d \
./control.d \
./delay.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./gray.d \
./icm42688.d \
./key.d \
./led.d \
./main.d \
./motor.d \
./oled.d \
./pca9685.d \
./qd4310.d \
./vl53l0x.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./CarStateSend.o \
./bmi088.o \
./buzzer.o \
./control.o \
./delay.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./gray.o \
./icm42688.o \
./key.o \
./led.o \
./main.o \
./motor.o \
./oled.o \
./pca9685.o \
./qd4310.o \
./vl53l0x.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"CarStateSend.o" \
"bmi088.o" \
"buzzer.o" \
"control.o" \
"delay.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"gray.o" \
"icm42688.o" \
"key.o" \
"led.o" \
"main.o" \
"motor.o" \
"oled.o" \
"pca9685.o" \
"qd4310.o" \
"vl53l0x.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"CarStateSend.d" \
"bmi088.d" \
"buzzer.d" \
"control.d" \
"delay.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"gray.d" \
"icm42688.d" \
"key.d" \
"led.d" \
"main.d" \
"motor.d" \
"oled.d" \
"pca9685.d" \
"qd4310.d" \
"vl53l0x.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../CarStateSend.c" \
"../bmi088.c" \
"../buzzer.c" \
"../control.c" \
"../delay.c" \
"./ti_msp_dl_config.c" \
"D:/Ti-Competitive/01_CCS_20.5.0.00028_win/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../gray.c" \
"../icm42688.c" \
"../key.c" \
"../led.c" \
"../main.c" \
"../motor.c" \
"../oled.c" \
"../pca9685.c" \
"../qd4310.c" \
"../vl53l0x.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


