/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000
/* Defines for SYSPLL_ERR_01 Workaround */
/* Represent 1.000 as 1000 */
#define FLOAT_TO_INT_SCALE                                               (1000U)
#define FCC_EXPECTED_RATIO                                                  2000
#define FCC_UPPER_BOUND                       (FCC_EXPECTED_RATIO * (1 + 0.003))
#define FCC_LOWER_BOUND                       (FCC_EXPECTED_RATIO * (1 - 0.003))

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);


/* Defines for MOTOR_PWM */
#define MOTOR_PWM_INST                                                     TIMA0
#define MOTOR_PWM_INST_IRQHandler                               TIMA0_IRQHandler
#define MOTOR_PWM_INST_INT_IRQN                                 (TIMA0_INT_IRQn)
#define MOTOR_PWM_INST_CLK_FREQ                                         80000000
/* GPIO defines for channel 0 */
#define GPIO_MOTOR_PWM_C0_PORT                                             GPIOA
#define GPIO_MOTOR_PWM_C0_PIN                                      DL_GPIO_PIN_8
#define GPIO_MOTOR_PWM_C0_IOMUX                                  (IOMUX_PINCM19)
#define GPIO_MOTOR_PWM_C0_IOMUX_FUNC                 IOMUX_PINCM19_PF_TIMA0_CCP0
#define GPIO_MOTOR_PWM_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_MOTOR_PWM_C1_PORT                                             GPIOB
#define GPIO_MOTOR_PWM_C1_PIN                                      DL_GPIO_PIN_9
#define GPIO_MOTOR_PWM_C1_IOMUX                                  (IOMUX_PINCM26)
#define GPIO_MOTOR_PWM_C1_IOMUX_FUNC                 IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_MOTOR_PWM_C1_IDX                                DL_TIMER_CC_1_INDEX



/* Defines for TIMER_1 */
#define TIMER_1_INST                                                     (TIMA1)
#define TIMER_1_INST_IRQHandler                                 TIMA1_IRQHandler
#define TIMER_1_INST_INT_IRQN                                   (TIMA1_INT_IRQn)
#define TIMER_1_INST_LOAD_VALUE                                            (99U)
/* Defines for TIMER_TOMOR_G0 */
#define TIMER_TOMOR_G0_INST                                              (TIMG0)
#define TIMER_TOMOR_G0_INST_IRQHandler                          TIMG0_IRQHandler
#define TIMER_TOMOR_G0_INST_INT_IRQN                            (TIMG0_INT_IRQn)
#define TIMER_TOMOR_G0_INST_LOAD_VALUE                                     (49U)




/* Defines for OLED */
#define OLED_INST                                                           I2C1
#define OLED_INST_IRQHandler                                     I2C1_IRQHandler
#define OLED_INST_INT_IRQN                                         I2C1_INT_IRQn
#define OLED_BUS_SPEED_HZ                                                 100000
#define GPIO_OLED_SDA_PORT                                                 GPIOA
#define GPIO_OLED_SDA_PIN                                         DL_GPIO_PIN_16
#define GPIO_OLED_IOMUX_SDA                                      (IOMUX_PINCM38)
#define GPIO_OLED_IOMUX_SDA_FUNC                       IOMUX_PINCM38_PF_I2C1_SDA
#define GPIO_OLED_SCL_PORT                                                 GPIOA
#define GPIO_OLED_SCL_PIN                                         DL_GPIO_PIN_29
#define GPIO_OLED_IOMUX_SCL                                       (IOMUX_PINCM4)
#define GPIO_OLED_IOMUX_SCL_FUNC                        IOMUX_PINCM4_PF_I2C1_SCL

/* Defines for Steering */
#define Steering_INST                                                       I2C0
#define Steering_INST_IRQHandler                                 I2C0_IRQHandler
#define Steering_INST_INT_IRQN                                     I2C0_INT_IRQn
#define Steering_BUS_SPEED_HZ                                             100000
#define GPIO_Steering_SDA_PORT                                             GPIOA
#define GPIO_Steering_SDA_PIN                                      DL_GPIO_PIN_0
#define GPIO_Steering_IOMUX_SDA                                   (IOMUX_PINCM1)
#define GPIO_Steering_IOMUX_SDA_FUNC                    IOMUX_PINCM1_PF_I2C0_SDA
#define GPIO_Steering_SCL_PORT                                             GPIOA
#define GPIO_Steering_SCL_PIN                                      DL_GPIO_PIN_1
#define GPIO_Steering_IOMUX_SCL                                   (IOMUX_PINCM2)
#define GPIO_Steering_IOMUX_SCL_FUNC                    IOMUX_PINCM2_PF_I2C0_SCL


/* Defines for WIFI */
#define WIFI_INST                                                          UART3
#define WIFI_INST_FREQUENCY                                             80000000
#define WIFI_INST_IRQHandler                                    UART3_IRQHandler
#define WIFI_INST_INT_IRQN                                        UART3_INT_IRQn
#define GPIO_WIFI_RX_PORT                                                  GPIOA
#define GPIO_WIFI_TX_PORT                                                  GPIOB
#define GPIO_WIFI_RX_PIN                                          DL_GPIO_PIN_25
#define GPIO_WIFI_TX_PIN                                           DL_GPIO_PIN_2
#define GPIO_WIFI_IOMUX_RX                                       (IOMUX_PINCM55)
#define GPIO_WIFI_IOMUX_TX                                       (IOMUX_PINCM15)
#define GPIO_WIFI_IOMUX_RX_FUNC                        IOMUX_PINCM55_PF_UART3_RX
#define GPIO_WIFI_IOMUX_TX_FUNC                        IOMUX_PINCM15_PF_UART3_TX
#define WIFI_BAUD_RATE                                                  (115200)
#define WIFI_IBRD_80_MHZ_115200_BAUD                                        (43)
#define WIFI_FBRD_80_MHZ_115200_BAUD                                        (26)
/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_FREQUENCY                                           40000000
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOA
#define GPIO_UART_2_TX_PORT                                                GPIOB
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_22
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_15
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM47)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM32)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM47_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM32_PF_UART2_TX
#define UART_2_BAUD_RATE                                                (115200)
#define UART_2_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_2_FBRD_40_MHZ_115200_BAUD                                      (45)
/* Defines for UART_1 */
#define UART_1_INST                                                        UART1
#define UART_1_INST_FREQUENCY                                           40000000
#define UART_1_INST_IRQHandler                                  UART1_IRQHandler
#define UART_1_INST_INT_IRQN                                      UART1_INT_IRQn
#define GPIO_UART_1_RX_PORT                                                GPIOB
#define GPIO_UART_1_TX_PORT                                                GPIOA
#define GPIO_UART_1_RX_PIN                                         DL_GPIO_PIN_7
#define GPIO_UART_1_TX_PIN                                        DL_GPIO_PIN_17
#define GPIO_UART_1_IOMUX_RX                                     (IOMUX_PINCM24)
#define GPIO_UART_1_IOMUX_TX                                     (IOMUX_PINCM39)
#define GPIO_UART_1_IOMUX_RX_FUNC                      IOMUX_PINCM24_PF_UART1_RX
#define GPIO_UART_1_IOMUX_TX_FUNC                      IOMUX_PINCM39_PF_UART1_TX
#define UART_1_BAUD_RATE                                                (115200)
#define UART_1_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_1_FBRD_40_MHZ_115200_BAUD                                      (45)
/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                           40000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_31
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_28
#define GPIO_UART_0_IOMUX_RX                                      (IOMUX_PINCM6)
#define GPIO_UART_0_IOMUX_TX                                      (IOMUX_PINCM3)
#define GPIO_UART_0_IOMUX_RX_FUNC                       IOMUX_PINCM6_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                       IOMUX_PINCM3_PF_UART0_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_0_FBRD_40_MHZ_115200_BAUD                                      (45)




/* Defines for BMI088_SPI_0 */
#define BMI088_SPI_0_INST                                                  SPI0
#define BMI088_SPI_0_INST_IRQHandler                            SPI0_IRQHandler
#define BMI088_SPI_0_INST_INT_IRQN                                SPI0_INT_IRQn
#define GPIO_BMI088_SPI_0_PICO_PORT                                       GPIOA
#define GPIO_BMI088_SPI_0_PICO_PIN                                DL_GPIO_PIN_9
#define GPIO_BMI088_SPI_0_IOMUX_PICO                            (IOMUX_PINCM20)
#define GPIO_BMI088_SPI_0_IOMUX_PICO_FUNC            IOMUX_PINCM20_PF_SPI0_PICO
#define GPIO_BMI088_SPI_0_POCI_PORT                                       GPIOA
#define GPIO_BMI088_SPI_0_POCI_PIN                               DL_GPIO_PIN_13
#define GPIO_BMI088_SPI_0_IOMUX_POCI                            (IOMUX_PINCM35)
#define GPIO_BMI088_SPI_0_IOMUX_POCI_FUNC            IOMUX_PINCM35_PF_SPI0_POCI
/* GPIO configuration for BMI088_SPI_0 */
#define GPIO_BMI088_SPI_0_SCLK_PORT                                       GPIOA
#define GPIO_BMI088_SPI_0_SCLK_PIN                               DL_GPIO_PIN_12
#define GPIO_BMI088_SPI_0_IOMUX_SCLK                            (IOMUX_PINCM34)
#define GPIO_BMI088_SPI_0_IOMUX_SCLK_FUNC            IOMUX_PINCM34_PF_SPI0_SCLK



/* Port definition for Pin Group BUZZER */
#define BUZZER_PORT                                                      (GPIOA)

/* Defines for BUZZER_A14: GPIOA.14 with pinCMx 36 on package pin 7 */
#define BUZZER_BUZZER_A14_PIN                                   (DL_GPIO_PIN_14)
#define BUZZER_BUZZER_A14_IOMUX                                  (IOMUX_PINCM36)
/* Port definition for Pin Group STEERING_EN */
#define STEERING_EN_PORT                                                 (GPIOB)

/* Defines for STEERING_EN_B11: GPIOB.11 with pinCMx 28 on package pin 63 */
#define STEERING_EN_STEERING_EN_B11_PIN                         (DL_GPIO_PIN_11)
#define STEERING_EN_STEERING_EN_B11_IOMUX                        (IOMUX_PINCM28)
/* Port definition for Pin Group VL53L0_EN */
#define VL53L0_EN_PORT                                                   (GPIOB)

/* Defines for VL53L0_EN_PB8: GPIOB.8 with pinCMx 25 on package pin 60 */
#define VL53L0_EN_VL53L0_EN_PB8_PIN                              (DL_GPIO_PIN_8)
#define VL53L0_EN_VL53L0_EN_PB8_IOMUX                            (IOMUX_PINCM25)
/* Defines for LED_A24: GPIOA.24 with pinCMx 54 on package pin 25 */
#define LED_LED_A24_PORT                                                 (GPIOA)
#define LED_LED_A24_PIN                                         (DL_GPIO_PIN_24)
#define LED_LED_A24_IOMUX                                        (IOMUX_PINCM54)
/* Defines for LED_B19: GPIOB.19 with pinCMx 45 on package pin 16 */
#define LED_LED_B19_PORT                                                 (GPIOB)
#define LED_LED_B19_PIN                                         (DL_GPIO_PIN_19)
#define LED_LED_B19_IOMUX                                        (IOMUX_PINCM45)
/* Defines for KEY_B16: GPIOB.16 with pinCMx 33 on package pin 4 */
#define KEY_KEY_B16_PORT                                                 (GPIOB)
// groups represented: ["TOMOR_FEEDBACK","KEY"]
// pins affected: ["E2B","E1A","KEY_B16","KEY_B14"]
#define GPIO_MULTIPLE_GPIOB_INT_IRQN                            (GPIOB_INT_IRQn)
#define GPIO_MULTIPLE_GPIOB_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define KEY_KEY_B16_IIDX                                    (DL_GPIO_IIDX_DIO16)
#define KEY_KEY_B16_PIN                                         (DL_GPIO_PIN_16)
#define KEY_KEY_B16_IOMUX                                        (IOMUX_PINCM33)
/* Defines for KEY_A07: GPIOA.7 with pinCMx 14 on package pin 49 */
#define KEY_KEY_A07_PORT                                                 (GPIOA)
// groups represented: ["TOMOR_FEEDBACK","KEY"]
// pins affected: ["E2A","E1B","KEY_A07","KEY_A15"]
#define GPIO_MULTIPLE_GPIOA_INT_IRQN                            (GPIOA_INT_IRQn)
#define GPIO_MULTIPLE_GPIOA_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define KEY_KEY_A07_IIDX                                     (DL_GPIO_IIDX_DIO7)
#define KEY_KEY_A07_PIN                                          (DL_GPIO_PIN_7)
#define KEY_KEY_A07_IOMUX                                        (IOMUX_PINCM14)
/* Defines for KEY_A15: GPIOA.15 with pinCMx 37 on package pin 8 */
#define KEY_KEY_A15_PORT                                                 (GPIOA)
#define KEY_KEY_A15_IIDX                                    (DL_GPIO_IIDX_DIO15)
#define KEY_KEY_A15_PIN                                         (DL_GPIO_PIN_15)
#define KEY_KEY_A15_IOMUX                                        (IOMUX_PINCM37)
/* Defines for KEY_B14: GPIOB.14 with pinCMx 31 on package pin 2 */
#define KEY_KEY_B14_PORT                                                 (GPIOB)
#define KEY_KEY_B14_IIDX                                    (DL_GPIO_IIDX_DIO14)
#define KEY_KEY_B14_PIN                                         (DL_GPIO_PIN_14)
#define KEY_KEY_B14_IOMUX                                        (IOMUX_PINCM31)
/* Port definition for Pin Group GRAY */
#define GRAY_PORT                                                        (GPIOB)

/* Defines for GRAY_B20: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GRAY_GRAY_B20_PIN                                       (DL_GPIO_PIN_20)
#define GRAY_GRAY_B20_IOMUX                                      (IOMUX_PINCM48)
/* Defines for GRAY_B21: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GRAY_GRAY_B21_PIN                                       (DL_GPIO_PIN_21)
#define GRAY_GRAY_B21_IOMUX                                      (IOMUX_PINCM49)
/* Defines for GRAY_B22: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GRAY_GRAY_B22_PIN                                       (DL_GPIO_PIN_22)
#define GRAY_GRAY_B22_IOMUX                                      (IOMUX_PINCM50)
/* Defines for GRAY_B23: GPIOB.23 with pinCMx 51 on package pin 22 */
#define GRAY_GRAY_B23_PIN                                       (DL_GPIO_PIN_23)
#define GRAY_GRAY_B23_IOMUX                                      (IOMUX_PINCM51)
/* Defines for GRAY_B24: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GRAY_GRAY_B24_PIN                                       (DL_GPIO_PIN_24)
#define GRAY_GRAY_B24_IOMUX                                      (IOMUX_PINCM52)
/* Defines for GRAY_B25: GPIOB.25 with pinCMx 56 on package pin 27 */
#define GRAY_GRAY_B25_PIN                                       (DL_GPIO_PIN_25)
#define GRAY_GRAY_B25_IOMUX                                      (IOMUX_PINCM56)
/* Defines for GRAY_B26: GPIOB.26 with pinCMx 57 on package pin 28 */
#define GRAY_GRAY_B26_PIN                                       (DL_GPIO_PIN_26)
#define GRAY_GRAY_B26_IOMUX                                      (IOMUX_PINCM57)
/* Defines for GRAY_B27: GPIOB.27 with pinCMx 58 on package pin 29 */
#define GRAY_GRAY_B27_PIN                                       (DL_GPIO_PIN_27)
#define GRAY_GRAY_B27_IOMUX                                      (IOMUX_PINCM58)
/* Port definition for Pin Group BMI088_CS */
#define BMI088_CS_PORT                                                   (GPIOB)

/* Defines for BMI088_CS1: GPIOB.12 with pinCMx 29 on package pin 64 */
#define BMI088_CS_BMI088_CS1_PIN                                (DL_GPIO_PIN_12)
#define BMI088_CS_BMI088_CS1_IOMUX                               (IOMUX_PINCM29)
/* Defines for BMI088_CS2: GPIOB.13 with pinCMx 30 on package pin 1 */
#define BMI088_CS_BMI088_CS2_PIN                                (DL_GPIO_PIN_13)
#define BMI088_CS_BMI088_CS2_IOMUX                               (IOMUX_PINCM30)
/* Port definition for Pin Group TOMOR_CONTROL */
#define TOMOR_CONTROL_PORT                                               (GPIOB)

/* Defines for BIN2: GPIOB.3 with pinCMx 16 on package pin 51 */
#define TOMOR_CONTROL_BIN2_PIN                                   (DL_GPIO_PIN_3)
#define TOMOR_CONTROL_BIN2_IOMUX                                 (IOMUX_PINCM16)
/* Defines for BIN1: GPIOB.4 with pinCMx 17 on package pin 52 */
#define TOMOR_CONTROL_BIN1_PIN                                   (DL_GPIO_PIN_4)
#define TOMOR_CONTROL_BIN1_IOMUX                                 (IOMUX_PINCM17)
/* Defines for AIN2: GPIOB.5 with pinCMx 18 on package pin 53 */
#define TOMOR_CONTROL_AIN2_PIN                                   (DL_GPIO_PIN_5)
#define TOMOR_CONTROL_AIN2_IOMUX                                 (IOMUX_PINCM18)
/* Defines for AIN1: GPIOB.10 with pinCMx 27 on package pin 62 */
#define TOMOR_CONTROL_AIN1_PIN                                  (DL_GPIO_PIN_10)
#define TOMOR_CONTROL_AIN1_IOMUX                                 (IOMUX_PINCM27)
/* Defines for E2A: GPIOA.26 with pinCMx 59 on package pin 30 */
#define TOMOR_FEEDBACK_E2A_PORT                                          (GPIOA)
#define TOMOR_FEEDBACK_E2A_IIDX                             (DL_GPIO_IIDX_DIO26)
#define TOMOR_FEEDBACK_E2A_PIN                                  (DL_GPIO_PIN_26)
#define TOMOR_FEEDBACK_E2A_IOMUX                                 (IOMUX_PINCM59)
/* Defines for E2B: GPIOB.17 with pinCMx 43 on package pin 14 */
#define TOMOR_FEEDBACK_E2B_PORT                                          (GPIOB)
#define TOMOR_FEEDBACK_E2B_IIDX                             (DL_GPIO_IIDX_DIO17)
#define TOMOR_FEEDBACK_E2B_PIN                                  (DL_GPIO_PIN_17)
#define TOMOR_FEEDBACK_E2B_IOMUX                                 (IOMUX_PINCM43)
/* Defines for E1A: GPIOB.18 with pinCMx 44 on package pin 15 */
#define TOMOR_FEEDBACK_E1A_PORT                                          (GPIOB)
#define TOMOR_FEEDBACK_E1A_IIDX                             (DL_GPIO_IIDX_DIO18)
#define TOMOR_FEEDBACK_E1A_PIN                                  (DL_GPIO_PIN_18)
#define TOMOR_FEEDBACK_E1A_IOMUX                                 (IOMUX_PINCM44)
/* Defines for E1B: GPIOA.27 with pinCMx 60 on package pin 31 */
#define TOMOR_FEEDBACK_E1B_PORT                                          (GPIOA)
#define TOMOR_FEEDBACK_E1B_IIDX                             (DL_GPIO_IIDX_DIO27)
#define TOMOR_FEEDBACK_E1B_PIN                                  (DL_GPIO_PIN_27)
#define TOMOR_FEEDBACK_E1B_IOMUX                                 (IOMUX_PINCM60)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);
void SYSCFG_DL_MOTOR_PWM_init(void);
void SYSCFG_DL_TIMER_1_init(void);
void SYSCFG_DL_TIMER_TOMOR_G0_init(void);
void SYSCFG_DL_OLED_init(void);
void SYSCFG_DL_Steering_init(void);
void SYSCFG_DL_WIFI_init(void);
void SYSCFG_DL_UART_2_init(void);
void SYSCFG_DL_UART_1_init(void);
void SYSCFG_DL_UART_0_init(void);
void SYSCFG_DL_BMI088_SPI_0_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
