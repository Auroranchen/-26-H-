/*
 * =========================== gray.h ===========================
 *  简介：
 *      8 路数字灰度循迹模块驱动。把 SysConfig 生成的 8 个输入引脚
 *      (GRAY_B20 ~ GRAY_B27) 再包一层, 提供:
 *          - 一次性读回 8 路电平        Gray_Read
 *          - 取某一路的值               Gray_Get
 *          - 算出车相对黑线的"偏差"      Gray_GetError  (循迹控制用)
 *          - 丢线/十字(全白/全黑)判断    Gray_IsLost / Gray_IsAllOn
 *
 *  硬件：
 *      8 路探头从左到右依次接:
 *          ch0=B20  ch1=B21  ch2=B22  ch3=B23
 *          ch4=B24  ch5=B25  ch6=B26  ch7=B27
 *      (从左到右的物理顺序请按你实际装车确认, 装反了把 s_gray[] 顺序调一下即可)
 *
 *  电平逻辑：
 *      本项目为「压到黑线 = 高电平(1)」。若你的模块相反(压线=0),
 *      把下面的 GRAY_LINE_ON_HIGH 改成 0 即可, 不用改别处。
 *
 *  偏差(error)定义：
 *      给 8 路探头从左到右赋权重 -7 -5 -3 -1 +1 +3 +5 +7。
 *      1~2 路压线时直接返回权重和, 保留高速弯道所需的纠偏幅度;
 *      3 路及以上压线时返回 Σ权重 / 压线路数。
 *          - 线在正中间 -> error≈0
 *          - 线偏左     -> error<0
 *          - 线偏右     -> error>0
 *      两路同时压线时误差最大可到约 -12~+12; 循迹时让 error 趋近 0。
 *
 *  使用方法：
 *      #include "gray.h"
 *      SYSCFG_DL_init();              // 引脚已在此初始化好
 *      Gray_Read();                   // 刷新一次 8 路电平
 *      float e = Gray_GetError();     // 拿偏差喂给循迹PID
 * ===============================================================
 */
#ifndef GRAY_H
#define GRAY_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- 探头数量 ---- */
#define GRAY_CH_NUM         8

/* ---- 电平逻辑: 1=压线读到高(默认)  0=压线读到低 ---- */
#define GRAY_LINE_ON_HIGH   1

/* Gray_GetError 在"完全丢线"时返回的哨兵值, 上层据此判断丢线。 */
#define GRAY_ERROR_LOST     (99999.0f)

/*
 * Gray_Read   - 读取一次 8 路探头电平, 存入内部缓存
 *               (其余取值函数都读这个缓存, 所以每个控制周期先调一次)
 */
void Gray_Read(void);

/*
 * Gray_Get    - 返回第 ch 路的压线状态: 1=压线, 0=没压
 *               ch 取 0~7 (左->右); 越界返回 0
 */
uint8_t Gray_Get(uint8_t ch);

/*
 * Gray_GetError - 返回当前偏差(见头部"偏差定义")。
 *                 完全丢线时返回 GRAY_ERROR_LOST。
 */
float Gray_GetError(void);

/*
 * Gray_IsLost  - 8 路全没压线(可能冲出赛道)返回 1
 * Gray_IsAllOn - 8 路全压线(十字/起跑线/终点)返回 1
 * (调用前需先 Gray_Read 刷新)
 */
uint8_t Gray_IsLost(void);
uint8_t Gray_IsAllOn(void);

/*
 * Gray_LeftCount  - 返回左半区(ch0~ch3)压线路数(0~4)
 * Gray_RightCount - 返回右半区(ch4~ch7)压线路数(0~4)
 *   用于直角检测: 某一侧连续多路同时压线, 判为该侧直角。
 *   (调用前需先 Gray_Read 刷新)
 */
uint8_t Gray_LeftCount(void);
uint8_t Gray_RightCount(void);

#ifdef __cplusplus
}
#endif

#endif /* GRAY_H */
