/*
 * ============================ led.h ============================
 *  简介：
 *      MSPM0G3507 板载两个 LED 的简易驱动封装。
 *      把 SysConfig 生成的 GPIO 宏（LED_LED_A24 / LED_LED_B19）
 *      再包一层，提供 开 / 关 / 翻转 / 写电平 等直接可调用的函数，
 *      不用每次都记 GPIOA / GPIOB 和引脚宏。
 *
 *  硬件：
 *      LED1 -> GPIOA.24  (SysConfig 名称: LED_A24)
 *      LED2 -> GPIOB.19  (SysConfig 名称: LED_B19)
 *
 *  使用方法：
 *      1. 在 main.c 顶部包含本头文件：
 *              #include "led.h"
 *
 *      2. 在 main() 里先调用一次芯片初始化（SysConfig 生成的）：
 *              SYSCFG_DL_init();
 *         这一步已经把两个 LED 的 GPIO 初始化好了，
 *         所以本库不需要再单独初始化，直接用即可。
 *
 *      3. 之后随意调用：
 *              LED_On(LED1);            // 点亮 LED1
 *              LED_Off(LED2);           // 熄灭 LED2
 *              LED_Toggle(LED1);        // 翻转 LED1
 *              LED_Write(LED2, 1);      // 1=亮, 0=灭
 *              LED_AllOn();             // 全亮
 *              LED_AllOff();            // 全灭
 *
 *  电平逻辑：
 *      默认「高电平点亮」。若你的板子是「低电平点亮」，
 *      把下面的 LED_ACTIVE_HIGH 改成 0 即可，无需改别处。
 * ===============================================================
 */
#ifndef LED_H
#define LED_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- 电平逻辑：1=高电平点亮(默认)  0=低电平点亮 ---- */
#define LED_ACTIVE_HIGH   1

/* ---- LED 编号：调用所有函数时用它来指定哪一个灯 ---- */
typedef enum {
    LED1 = 0,   /* GPIOA.24 */
    LED2,       /* GPIOB.19 */
    LED_COUNT   /* 灯的总数, 勿删 */
} LED_ID;

/*
 * LED_On    - 点亮指定 LED
 * LED_Off   - 熄灭指定 LED
 * LED_Toggle- 翻转指定 LED 当前状态
 * LED_Write - 直接写状态: on=1 点亮, on=0 熄灭
 * 参数 id 取 LED1 / LED2
 */
void LED_On(LED_ID id);
void LED_Off(LED_ID id);
void LED_Toggle(LED_ID id);
void LED_Write(LED_ID id, uint8_t on);

/* 一次性操作所有 LED */
void LED_AllOn(void);
void LED_AllOff(void);

#ifdef __cplusplus
}
#endif

#endif /* LED_H */
