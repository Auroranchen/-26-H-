/*
 * =========================== motor.h ===========================
 *  简介：
 *      双直流电机(TB6612 驱动)封装 + 编码器测速。
 *      提供:
 *          - 启动 PWM 定时器           Motor_Init
 *          - 设占空比                  Motor_SetDuty
 *          - 设方向                    Motor_SetDir
 *          - 停车                      Motor_Stop / Motor_StopAll
 *          - 带符号速度控制(方向+占空比一步到位) Motor_Drive
 *          - 读编码器计数/清零          Motor_GetCount / Motor_ClearCount
 *
 *  电机编号：
 *      MOTOR_L (1) = 左轮  : PWMA=A8, AIN1=B10, AIN2=B5 , 编码器A相 E1A=B18
 *      MOTOR_R (2) = 右轮  : PWMB=B9, BIN1=B4 , BIN2=B3 , 编码器A相 E2A=A26
 *      (左右/正反若和实车不符, 见 motor.c 顶部 s_motor[] 表和 Motor_Drive 极性说明)
 *
 *  PWM：
 *      TIMA0(MOTOR_PWM), period=8000 -> 占空比范围 0~MOTOR_DUTY_MAX(=8000)。
 *      占空比 = 比较值; 越大轮子越快。
 *
 *  编码器：
 *      4 个反馈引脚都由 SysConfig 配了上升沿中断, 全部汇入 GROUP1_IRQHandler
 *      (本文件实现)。默认只用 A 相计数(单相测速, 不辨方向); B 相已读入,
 *      需要辨向时可在中断里扩展。
 *
 *  STBY：
 *      已直接接高电平, 软件无需控制。
 *
 *  使用方法：
 *      #include "motor.h"
 *      SYSCFG_DL_init();
 *      Motor_Init();                       // 启动PWM + 使能编码器中断
 *      Motor_Drive(MOTOR_L, 3000);         // 左轮正转, 占空比3000
 *      Motor_Drive(MOTOR_R, -2000);        // 右轮反转, 占空比2000
 *      int32_t c = Motor_GetCount(MOTOR_L);// 读左轮编码器脉冲数
 * ===============================================================
 */
#ifndef MOTOR_H
#define MOTOR_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- 电机编号 ---- */
typedef enum {
    MOTOR_L = 0,    /* 左轮 */
    MOTOR_R,        /* 右轮 */
    MOTOR_NUM       /* 电机总数, 勿删 */
} Motor_ID;

/* ---- 占空比上限(= SysConfig 里 MOTOR_PWM 的 period) ---- */
#define MOTOR_DUTY_MAX      8000

/*
 * Motor_Init - 启动 PWM 定时器, 使能编码器 GPIO 中断。
 *              (引脚本身已由 SYSCFG_DL_init 配好, 这里做运行期启动)
 */
void Motor_Init(void);

/*
 * Motor_SetDuty - 设置某电机 PWM 占空比(不改方向)。
 *                 duty 自动限幅到 0~MOTOR_DUTY_MAX。
 */
void Motor_SetDuty(Motor_ID id, int32_t duty);

/*
 * Motor_SetDir - 设置某电机方向。dir: 0=停(刹车) 1=正转 2=反转
 */
void Motor_SetDir(Motor_ID id, uint8_t dir);

/*
 * Motor_Drive - 带符号驱动: duty>0 正转, duty<0 反转, duty=0 停。
 *               |duty| 作为占空比(自动限幅)。循迹控制推荐用这个。
 */
void Motor_Drive(Motor_ID id, int32_t duty);

/* Motor_Stop    - 停指定电机(占空比清0并刹车) */
/* Motor_StopAll - 停所有电机 */
void Motor_Stop(Motor_ID id);
void Motor_StopAll(void);
void Motor_Brake(Motor_ID id);
  void Motor_BrakeAll(void);

/*
 * Motor_GetCount   - 读某电机编码器累加脉冲数(自上次清零起)
 * Motor_ClearCount - 清零某电机编码器计数(测速时每周期读完即清)
 */
int32_t Motor_GetCount(Motor_ID id);
void    Motor_ClearCount(Motor_ID id);

#ifdef __cplusplus
}
#endif

#endif /* MOTOR_H */
