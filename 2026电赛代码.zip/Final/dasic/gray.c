/*
 * =========================== gray.c ===========================
 *  8 路数字灰度循迹驱动实现。详细说明见 gray.h 头部注释。
 * ===============================================================
 */
#include "gray.h"

/* 用一张表把 8 路探头的 端口/引脚 集中管理,
 * 顺序 = 从左到右(ch0=最左)。装反了改这里顺序即可, 上层不动。 */
typedef struct {
    GPIO_Regs *port;
    uint32_t   pin;
} Gray_Map;

static const Gray_Map s_gray[GRAY_CH_NUM] = {
    { GRAY_PORT, GRAY_GRAY_B20_PIN },   /* ch0  最左 */
    { GRAY_PORT, GRAY_GRAY_B21_PIN },   /* ch1  */
    { GRAY_PORT, GRAY_GRAY_B22_PIN },   /* ch2  */
    { GRAY_PORT, GRAY_GRAY_B23_PIN },   /* ch3  */
    { GRAY_PORT, GRAY_GRAY_B24_PIN },   /* ch4  */
    { GRAY_PORT, GRAY_GRAY_B25_PIN },   /* ch5  */
    { GRAY_PORT, GRAY_GRAY_B26_PIN },   /* ch6  */
    { GRAY_PORT, GRAY_GRAY_B27_PIN },   /* ch7  最右 */
};

/* 从左到右的权重, 居中对称, 用于加权求偏差。
 * 负=偏左, 正=偏右; 数越大代表离中线越远。 */
static const int8_t s_weight[GRAY_CH_NUM] = { -7, -5, -3, -1, +1, +3, +5, +7 };

/* 每次 Gray_Read 把 8 路压线状态(0/1)缓存在这里 */
static uint8_t s_val[GRAY_CH_NUM] = {0};

void Gray_Read(void)
{
    for (uint8_t i = 0; i < GRAY_CH_NUM; i++) {
        uint32_t level = DL_GPIO_readPins(s_gray[i].port, s_gray[i].pin);
        uint8_t  high  = (level & s_gray[i].pin) ? 1 : 0;
#if GRAY_LINE_ON_HIGH
        s_val[i] = high;            /* 压线=高 */
#else
        s_val[i] = high ? 0 : 1;    /* 压线=低: 取反 */
#endif
    }
}

uint8_t Gray_Get(uint8_t ch)
{
    if (ch >= GRAY_CH_NUM) return 0;
    return s_val[ch];
}

float Gray_GetError(void)
{
    int32_t sum_w = 0;   /* Σ(权重×压线) */
    int32_t cnt   = 0;   /* Σ(压线) */

    for (uint8_t i = 0; i < GRAY_CH_NUM; i++) {
        if (s_val[i]) {
            sum_w += s_weight[i];
            cnt++;
        }
    }

    if (cnt == 0) {
        return GRAY_ERROR_LOST;     /* 完全丢线 */
    }
    /* 参考循迹算法: 仅 1~2 路压线时不归一化, 保留较大的边缘误差,
     * 让高速入弯时有足够纠偏力度; 3 路及以上再取质心平均。 */
    if (cnt <= 2) {
        return (float)sum_w;
    }
    return (float)sum_w / (float)cnt;
}

uint8_t Gray_IsLost(void)
{
    for (uint8_t i = 0; i < GRAY_CH_NUM; i++) {
        if (s_val[i]) return 0;
    }
    return 1;
}

uint8_t Gray_IsAllOn(void)
{
    for (uint8_t i = 0; i < GRAY_CH_NUM; i++) {
        if (!s_val[i]) return 0;
    }
    return 1;
}

uint8_t Gray_LeftCount(void)
{
    uint8_t n = 0;
    for (uint8_t i = 0; i < GRAY_CH_NUM / 2; i++) {   /* ch0~ch3 */
        if (s_val[i]) n++;
    }
    return n;
}

uint8_t Gray_RightCount(void)
{
    uint8_t n = 0;
    for (uint8_t i = GRAY_CH_NUM / 2; i < GRAY_CH_NUM; i++) {   /* ch4~ch7 */
        if (s_val[i]) n++;
    }
    return n;
}
