/*
 * ========================== control.c ==========================
 *  8 路灰度加权质心 + PID 差速循迹。控制参数和输出限制采用
 *  《循迹运行逻辑》参考方案, 编码器仅用于测速显示和里程累计。
 * ===============================================================
 */
#include "control.h"
#include "gray.h"
#include "motor.h"
#include "delay.h"

/* ================= 可调参数 ================= */

/* 若实车纠偏方向整体相反, 只把这里改成 -1。 */
#define CTRL_DIR_SIGN          (+1)

#define CTRL_DIV               10       /* 1ms 中断分频为 10ms, 即 100Hz */
#define CTRL_PWM_FULL          1000     /* 参考方案的 PWM 计算域 */
#define CTRL_BASE_SPEED        300      /* 直道基础速度 */
#define CTRL_CURVE_MIN_SPEED   190      /* 大弯最低基速, 保留足够通过速度 */
#define CTRL_CURVE_SLOW_K      10.0f    /* 每单位偏差降低的基速 */
#define CTRL_CURVE_ENTER_ERR   1.5f     /* 超过该误差才启用弯道优化, 直线保持原控制 */
#define CTRL_WHEEL_MAX         500      /* 参考方案单轮安全上限 */
#define CTRL_KP                20.0f
#define CTRL_KI                0.0f
#define CTRL_KD                5.5f
#define EVENT4_BASE_SPEED      235      /* EVENT4 参考方案基础速度 */
#define EVENT4_KP              14.0f    /* EVENT4 降低直线纠偏灵敏度，减少摆动 */
#define EVENT4_KI              0.0f
#define EVENT4_KD              1.0f     /* EVENT4 抑制数字灰度跳变引起的小抖动 */
#define CTRL_ADJUST_MAX        500.0f
#define CTRL_ADJUST_STEP_MAX   55.0f    /* 单周期纠偏变化上限, 减少出入弯抖动 */
#define CTRL_ERROR_FILTER      0.65f    /* 误差低通: 越大响应越快 */
#define CTRL_D_FILTER          0.35f    /* D 项低通, 抑制数字探头跳变 */
#define CTRL_I_LIMIT           80.0f
#define CTRL_MIN_RATIO_PCT     15       /* 内侧轮至少保留有效基速的 15% */

#define CTRL_LOST_HOLD         15       /* 15 个周期 = 150ms */
#define CTRL_SEEK_ERR          4.0f

#define EVENT2_ARM_MS          12000U   /* 正常约16s一圈，12s后才允许识别返回A */
#define EVENT2_CLEAR_FRAMES    5U       /* 连续50ms不满足A条件，确认已离开起点 */
#define EVENT2_CONFIRM_FRAMES  2U       /* A条件连续20ms，过滤单周期毛刺 */
#define EVENT2_TRACK_MM        6142U
#define EVENT2_TAIL_MM         320U
#define EVENT2_TAIL_MIN_MS     700U
#define EVENT2_TAIL_MAX_MS     1000U
#define EVENT2_RIGHT_REVERSE_MS 500U    /* 到达停车点后右轮按弯道最低速度反转0.5s */
#define EVENT2_RIGHT_REVERSE_PWM (CTRL_CURVE_MIN_SPEED * 78 / 100) /* 右轮后转速度在降低35%的基础上提升20% */
 #define EVENT2_DECEL_START_MS   0U    /* 停车前多少ms开始线性降速 */
  #define EVENT2_DECEL_SCALE_PCT  40      /* 降速终点：基速的百分比 */
  #define EVENT2_BRAKE_OFFSET_MS  0U      /* 制动距离预补偿(ms)，实车标定后填入 */

/* ================= 内部状态 ================= */

static volatile uint8_t  s_running = 0;
static volatile uint16_t s_div_cnt = 0;

static float   s_error = 0.0f;
static float   s_filtered_error = 0.0f; /* 数字灰度误差滤波值 */
static float   s_last_error = 0.0f;     /* 上周期滤波误差, 只在算完 D 后更新 */
static float   s_derivative = 0.0f;     /* 滤波后的 D 项 */
static float   s_last_adjust = 0.0f;    /* 上周期纠偏量, 用于输出斜率限制 */
static float   s_integral = 0.0f;
static int8_t  s_last_dir = 0;          /* 最近有效方向: -1 左, +1 右 */
static uint16_t s_lost_cnt = 0;

static volatile int32_t s_speed[2] = {0, 0};
static volatile int32_t s_odo = 0;
static volatile uint8_t s_spd_scale = 100;
static volatile uint8_t s_event4_mode = 0;

static volatile ControlEvent2State s_event2_state = CONTROL_EVENT2_OFF;
static volatile ControlEvent2StopReason s_event2_stop_reason = CONTROL_EVENT2_STOP_NONE;
static uint32_t s_event2_start_tick = 0;
static uint32_t s_event2_candidate_tick = 0;
static uint32_t s_event2_detect_tick = 0;
static uint16_t s_event2_tail_delay_ms = 0;
static uint32_t s_event2_right_reverse_tick = 0;
static uint8_t s_event2_clear_frames = 0;
static uint8_t s_event2_candidate_frames = 0;
static volatile uint32_t s_event2_finish_tick = 0;
static volatile int32_t s_event2_stop_odo = 0;

/* ================= 小工具 ================= */

static int32_t clamp_i32(int32_t value, int32_t low, int32_t high)
{
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

static float abs_f(float value)
{
    return (value >= 0.0f) ? value : -value;
}

/* 把参考方案的 0~1000 命令换算为本工程 0~MOTOR_DUTY_MAX 的逻辑占空比。 */
static int32_t ref_pwm_to_duty(int32_t pwm)
{
    return (pwm * MOTOR_DUTY_MAX) / CTRL_PWM_FULL;
}

static void drive_ref_pwm(int32_t left, int32_t right, int32_t base)
{
    if (base <= 0) {
        Motor_StopAll();
        return;
    }

    int32_t min_speed = (base * CTRL_MIN_RATIO_PCT) / 100;
    if (min_speed < 1) min_speed = 1;

    left  = clamp_i32(left,  min_speed, CTRL_WHEEL_MAX);
    right = clamp_i32(right, min_speed, CTRL_WHEEL_MAX);

    Motor_Drive(MOTOR_L, ref_pwm_to_duty(left));
    Motor_Drive(MOTOR_R, ref_pwm_to_duty(right));
}

 static void event2_finish(uint32_t now, ControlEvent2StopReason reason)
  {
      s_running = 0;
      Motor_BrakeAll();                   // ← 短接制动，立刻减速
      s_event2_stop_odo = s_odo;
      s_event2_finish_tick = now;
      s_event2_stop_reason = reason;
      s_event2_state = CONTROL_EVENT2_DONE;
  }


static uint8_t gray_on_count(void)
{
    uint8_t count = 0;
    uint8_t i;

    for (i = 0; i < GRAY_CH_NUM; i++) {
        count += Gray_Get(i);
    }
    return count;
}

static uint16_t event2_tail_delay(uint32_t detect_elapsed_ms)
{
    uint32_t delay_ms = (detect_elapsed_ms * EVENT2_TAIL_MM +
                         EVENT2_TRACK_MM / 2U) / EVENT2_TRACK_MM;

    if (delay_ms < EVENT2_TAIL_MIN_MS) delay_ms = EVENT2_TAIL_MIN_MS;
      if (delay_ms > EVENT2_TAIL_MAX_MS) delay_ms = EVENT2_TAIL_MAX_MS;
      /* 制动距离预补偿：提前断油，让刹车把惯性吃掉 */
      if (delay_ms > EVENT2_BRAKE_OFFSET_MS)
          delay_ms -= EVENT2_BRAKE_OFFSET_MS;
      else
          delay_ms = 0;
      return (uint16_t)delay_ms;

}

/* Gray_Read 已在本周期完成。返回 1 表示已停车，调用者必须立即退出，
 * 防止后续 PID 输出重新驱动电机。 */
static uint8_t event2_update_after_gray(void)
{
    uint32_t now;
    uint8_t on_count;

    if (s_event2_state == CONTROL_EVENT2_OFF ||
        s_event2_state == CONTROL_EVENT2_DONE) {
        return 0;
    }

    now = Delay_GetTick();
    on_count = gray_on_count();

    switch (s_event2_state) {
        case CONTROL_EVENT2_WAIT_CLEAR:
            if (on_count <= 3U) {
                if (++s_event2_clear_frames >= EVENT2_CLEAR_FRAMES) {
                    s_event2_state = CONTROL_EVENT2_WAIT_ARM;
                }
            } else {
                s_event2_clear_frames = 0;
            }
            break;

        case CONTROL_EVENT2_WAIT_ARM:
            if (now - s_event2_start_tick >= EVENT2_ARM_MS) {
                s_event2_state = CONTROL_EVENT2_WAIT_A;
                s_event2_candidate_frames = 0;
            }
            break;

        case CONTROL_EVENT2_WAIT_A:
            if (on_count > 3U) {
                if (s_event2_candidate_frames == 0U) {
                    s_event2_candidate_tick = now;
                }
                if (++s_event2_candidate_frames >= EVENT2_CONFIRM_FRAMES) {
                    uint32_t detect_elapsed;
                    s_event2_detect_tick = s_event2_candidate_tick;
                    detect_elapsed = s_event2_detect_tick - s_event2_start_tick;
                    s_event2_tail_delay_ms = event2_tail_delay(detect_elapsed);
                    s_event2_state = CONTROL_EVENT2_TAIL_DELAY;
                }
            } else {
                s_event2_candidate_frames = 0;
            }
            break;

         case CONTROL_EVENT2_TAIL_DELAY:
          {
              uint32_t elapsed = now - s_event2_detect_tick;
              if (elapsed >= s_event2_tail_delay_ms) {
                  /* EVENT2 专用停车动作：左轮制动，右轮以正常过弯最低速度后退0.5s。 */
                  Motor_Brake(MOTOR_L);
                  Motor_Drive(MOTOR_R, -ref_pwm_to_duty(EVENT2_RIGHT_REVERSE_PWM));
                  s_event2_right_reverse_tick = now;
                  s_event2_state = CONTROL_EVENT2_RIGHT_REVERSE;
                  return 1;
              }

              /* 最后 EVENT2_DECEL_START_MS 内线性降速，减少刹车时的惯性动量 */
              uint32_t remaining = s_event2_tail_delay_ms - elapsed;
              if (remaining <= EVENT2_DECEL_START_MS) {
                  uint8_t scale = EVENT2_DECEL_SCALE_PCT
                      + (100 - EVENT2_DECEL_SCALE_PCT) * remaining
                        / EVENT2_DECEL_START_MS;
                  s_spd_scale = scale;
              }
              break;
          }

        case CONTROL_EVENT2_RIGHT_REVERSE:
            if (now - s_event2_right_reverse_tick >= EVENT2_RIGHT_REVERSE_MS) {
                event2_finish(now, CONTROL_EVENT2_STOP_A_TAIL);
            }
            return 1;

        default:
            break;
    }

    return 0;
}

/* ================= 巡线 ================= */

static void do_line_follow(void)
{
    Gray_Read();
    if (event2_update_after_gray()) {
        return;
    }

    int32_t control_base_speed = s_event4_mode ? EVENT4_BASE_SPEED : CTRL_BASE_SPEED;
    int32_t target_base = (control_base_speed * (int32_t)s_spd_scale) / 100;
    if (target_base <= 0) {
        s_error = 0.0f;
        s_filtered_error = 0.0f;
        s_last_error = 0.0f;
        s_derivative = 0.0f;
        s_last_adjust = 0.0f;
        s_integral = 0.0f;
        Motor_StopAll();
        return;
    }

    float raw_error = Gray_GetError();
    float error;
    uint8_t all_black = Gray_IsAllOn();

    if (raw_error >= GRAY_ERROR_LOST) {
        /* 短暂丢线时逐周期衰减转向; 超过 150ms 后朝最后方向搜线。 */
        if (s_lost_cnt < 0xFFFFu) s_lost_cnt++;
        if (s_lost_cnt > CTRL_LOST_HOLD) {
            error = (s_last_dir >= 0) ? CTRL_SEEK_ERR : -CTRL_SEEK_ERR;
        } else {
            error = s_last_error * 0.5f;
        }
    } else {
        s_lost_cnt = 0;
        error = raw_error;
        if (error < 0.0f) {
            s_last_dir = -1;
        } else if (error > 0.0f) {
            s_last_dir = 1;
        }
    }

    uint8_t in_curve = (abs_f(error) > CTRL_CURVE_ENTER_ERR) ? 1u : 0u;

    /* 直线沿用原始误差; 仅弯道启用上一版轻度滤波。 */
    if (in_curve) {
        s_filtered_error += CTRL_ERROR_FILTER * (error - s_filtered_error);
        error = s_filtered_error;
    } else {
        s_filtered_error = error;
    }
    s_error = error;

    /* 直线保持原基速; 仅弯道按偏差小幅降速。 */
    int32_t base = target_base;
    if (in_curve) {
        int32_t curve_min = (CTRL_CURVE_MIN_SPEED * (int32_t)s_spd_scale) / 100;
        base -= (int32_t)(CTRL_CURVE_SLOW_K * abs_f(error));
        if (base < curve_min) base = curve_min;
    }

    /* 全黑按停止线/十字处理: 本周期严格直行, 不产生 D 项瞬态。 */
    if (all_black) {
        s_filtered_error = 0.0f;
        s_last_error = 0.0f;
        s_derivative = 0.0f;
        s_last_adjust = 0.0f;
        s_integral = 0.0f;
        drive_ref_pwm(target_base, target_base, target_base);
        return;
    }

    s_integral += error;
    if (s_integral >  CTRL_I_LIMIT) s_integral =  CTRL_I_LIMIT;
    if (s_integral < -CTRL_I_LIMIT) s_integral = -CTRL_I_LIMIT;

    /* 直线保持原始 D 项; 仅弯道滤除数字探头切换产生的尖峰。 */
    float derivative_raw = error - s_last_error;
    float derivative;
    if (in_curve) {
        s_derivative += CTRL_D_FILTER * (derivative_raw - s_derivative);
        derivative = s_derivative;
    } else {
        s_derivative = derivative_raw;
        derivative = derivative_raw;
    }
    s_last_error = error;

    float kp = s_event4_mode ? EVENT4_KP : CTRL_KP;
    float ki = s_event4_mode ? EVENT4_KI : CTRL_KI;
    float kd = s_event4_mode ? EVENT4_KD : CTRL_KD;
    float adjust = kp * error
                 + ki * s_integral
                 + kd * derivative;

    if (adjust >  CTRL_ADJUST_MAX) adjust =  CTRL_ADJUST_MAX;
    if (adjust < -CTRL_ADJUST_MAX) adjust = -CTRL_ADJUST_MAX;

    /* 直线保留原始 PID 输出; 仅弯道限制转向突变量。 */
    if (in_curve) {
        float adjust_delta = adjust - s_last_adjust;
        if (adjust_delta > CTRL_ADJUST_STEP_MAX) {
            adjust = s_last_adjust + CTRL_ADJUST_STEP_MAX;
        } else if (adjust_delta < -CTRL_ADJUST_STEP_MAX) {
            adjust = s_last_adjust - CTRL_ADJUST_STEP_MAX;
        }
    }
    s_last_adjust = adjust;

    int32_t correction = (adjust >= 0.0f)
                       ? (int32_t)(adjust + 0.5f)
                       : (int32_t)(adjust - 0.5f);
    correction *= CTRL_DIR_SIGN;

    /* error>0 表示线在右: 左轮加速、右轮减速, 车辆向右纠偏。 */
    drive_ref_pwm(base + correction, base - correction, base);
}

/* ================= 对外接口 ================= */

void Control_Start(void)
{
    NVIC_EnableIRQ(TIMER_TOMOR_G0_INST_INT_IRQN);
    DL_Timer_startCounter(TIMER_TOMOR_G0_INST);
}

void Control_Run(void)
{
    s_running = 0;
    s_error = 0.0f;
    s_filtered_error = 0.0f;
    s_last_error = 0.0f;
    s_derivative = 0.0f;
    s_last_adjust = 0.0f;
    s_integral = 0.0f;
    s_last_dir = 0;
    s_lost_cnt = 0;
    s_odo = 0;
    s_spd_scale = 100;
    s_event4_mode = 0;
    s_event2_state = CONTROL_EVENT2_OFF;
    s_event2_finish_tick = 0;
    s_running = 1;
}

void Control_RunEvent4(void)
{
    s_running = 0;
    s_error = 0.0f;
    s_filtered_error = 0.0f;
    s_last_error = 0.0f;
    s_derivative = 0.0f;
    s_last_adjust = 0.0f;
    s_integral = 0.0f;
    s_last_dir = 0;
    s_lost_cnt = 0;
    s_odo = 0;
    s_spd_scale = 100;
    s_event4_mode = 1;
    s_event2_state = CONTROL_EVENT2_OFF;
    s_event2_finish_tick = 0;
    s_running = 1;
}

void Control_RunEvent5(void)
{
    /* EVENT5 的速度、PID 和巡线路线与 EVENT4 完全相同。 */
    Control_RunEvent4();
}

void Control_RunEvent2(void)
{
    s_running = 0;
    s_error = 0.0f;
    s_filtered_error = 0.0f;
    s_last_error = 0.0f;
    s_derivative = 0.0f;
    s_last_adjust = 0.0f;
    s_integral = 0.0f;
    s_last_dir = 0;
    s_lost_cnt = 0;
    s_odo = 0;
    s_spd_scale = 100;

    s_event2_start_tick = Delay_GetTick();
    s_event2_candidate_tick = 0;
    s_event2_detect_tick = 0;
    s_event2_tail_delay_ms = 0;
    s_event2_right_reverse_tick = 0;
    s_event2_clear_frames = 0;
    s_event2_candidate_frames = 0;
    s_event2_finish_tick = 0;
    s_event2_stop_odo = 0;
    s_event2_stop_reason = CONTROL_EVENT2_STOP_NONE;
    s_event2_state = CONTROL_EVENT2_WAIT_CLEAR;
    s_running = 1;
}

void Control_Stop(void)
{
    s_running = 0;
    s_error = 0.0f;
    s_filtered_error = 0.0f;
    s_last_error = 0.0f;
    s_derivative = 0.0f;
    s_last_adjust = 0.0f;
    s_integral = 0.0f;
    s_last_dir = 0;
    s_lost_cnt = 0;
    s_event4_mode = 0;
    if (s_event2_state != CONTROL_EVENT2_OFF &&
        s_event2_state != CONTROL_EVENT2_DONE) {
        s_event2_stop_odo = s_odo;
        s_event2_finish_tick = Delay_GetTick();
        s_event2_stop_reason = CONTROL_EVENT2_STOP_MANUAL;
    }
    s_event2_state = CONTROL_EVENT2_OFF;
     Motor_BrakeAll();
  }

uint8_t Control_IsRunning(void) { return s_running; }
float Control_GetError(void)    { return s_error; }
ControlEvent2State Control_GetEvent2State(void) { return s_event2_state; }
ControlEvent2StopReason Control_GetEvent2StopReason(void) { return s_event2_stop_reason; }
uint32_t Control_GetEvent2FinishTick(void) { return s_event2_finish_tick; }
int32_t Control_GetEvent2StopOdo(void) { return s_event2_stop_odo; }
uint32_t Control_GetEvent2DetectMs(void)
{
    return (s_event2_detect_tick == 0U) ? 0U :
           s_event2_detect_tick - s_event2_start_tick;
}
uint16_t Control_GetEvent2TailDelayMs(void) { return s_event2_tail_delay_ms; }

void Control_SetSpeedScale(uint8_t percent)
{
    if (percent > 100) percent = 100;
    s_spd_scale = percent;
}

int32_t Control_GetSpeed(uint8_t id)
{
    if (id > 1) return 0;
    return s_speed[id];
}

int32_t Control_GetOdo(void)   { return s_odo; }
void    Control_ClearOdo(void) { s_odo = 0; }

/* ================= TIMG0 1ms 中断 ================= */
void TIMER_TOMOR_G0_INST_IRQHandler(void)
{
    switch (DL_Timer_getPendingInterrupt(TIMER_TOMOR_G0_INST)) {
        case DL_TIMER_IIDX_ZERO:
            if (++s_div_cnt < CTRL_DIV) {
                break;
            }
            s_div_cnt = 0;

            /* 编码器保留用于速度显示和里程门限, 不参与 PID 输出。 */
            s_speed[0] = Motor_GetCount(MOTOR_L);
            s_speed[1] = Motor_GetCount(MOTOR_R);
            Motor_ClearCount(MOTOR_L);
            Motor_ClearCount(MOTOR_R);

            if (s_running) {
                s_odo += s_speed[0] + s_speed[1];
            } else {
                break;
            }

            do_line_follow();
            break;

        default:
            break;
    }
}
