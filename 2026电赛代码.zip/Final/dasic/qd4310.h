/*
 * =========================== qd4310.h ===========================
 *  QD4310 无刷驱控一体伺服电机 UART 驱动封装。
 *
 *  UART 协议(V2.7):
 *      控制包: ID, CMD, VALUE_L, VALUE_H, CRC8       (5 bytes)
 *      反馈包: ID, STATUS, RESERVED, CURRENT(2), SPEED(2), ANGLE(2), CRC8
 *              (10 bytes)
 *      CRC8: 多项式 0x07, 初值/结果异或 0x00, 无反射。
 *
 *  本工程串口分工(均由 SysConfig 配置为 115200 8N1):
 *      QD4310 通信: UART1
 *          MCU RX = PB7,  接 QD4310 TX
 *          MCU TX = PA17, 接 QD4310 RX
 *      调试信息输出: UART0
 *          MCU RX = PA31
 *          MCU TX = PA28, 接串口工具 RX
 *      两路串口及 QD4310 必须与 MCU 共地, UART 电平为 3.3V。
 *
 *  注意:
 *      - QD4310 要求严格“一发一收”, 本驱动为阻塞、同步、不可重入接口。
 *      - 调用 QD4310_* 命令前必须先 SYSCFG_DL_init() 和 Delay_TimerStart()。
 *      - QD4310_Init() 只初始化软件状态, 不会自动使能电机或让电机转动。
 *      - H题滚球控制建议使用 QD4310_SetCurrent() 接入外部闭环。
 * ===============================================================
 */
#ifndef QD4310_H
#define QD4310_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef QD4310_UART_INST
#define QD4310_UART_INST           UART_1_INST
#endif

#ifndef QD4310_DEBUG_UART_INST
#define QD4310_DEBUG_UART_INST     UART_0_INST
#endif

#ifndef QD4310_DEFAULT_ID
#define QD4310_DEFAULT_ID          0x01U
#endif

#ifndef QD4310_RX_TIMEOUT_MS
#define QD4310_RX_TIMEOUT_MS       10U
#endif

#define QD4310_PI               3.14159265358979323846f
#define QD4310_TWO_PI           (2.0f * QD4310_PI)

typedef enum {
    QD4310_CMD_NOP         = 0x00,
    QD4310_CMD_ENABLE      = 0x01,
    QD4310_CMD_DISABLE     = 0x02,
    QD4310_CMD_CURRENT     = 0x03,
    QD4310_CMD_SPEED       = 0x04,
    QD4310_CMD_ANGLE       = 0x05,
    QD4310_CMD_LOW_SPEED   = 0x06,
    QD4310_CMD_STEP_ANGLE  = 0x07,
    QD4310_CMD_CLEAR_ERROR = 0xFB,
    QD4310_CMD_ZERO        = 0xFE,
    QD4310_CMD_REBOOT      = 0xFF
} QD4310_Command;

typedef enum {
    QD4310_RESULT_OK = 0,
    QD4310_RESULT_INVALID_ARGUMENT,
    QD4310_RESULT_BUSY,
    QD4310_RESULT_TIMEOUT,
    QD4310_RESULT_ID_MISMATCH,
    QD4310_RESULT_CRC_ERROR,
    QD4310_RESULT_UART_ERROR
} QD4310_Result;

typedef struct {
    uint8_t  id;
    uint8_t  status;
    uint8_t  reserved;
    int16_t  current_raw;
    int16_t  speed_raw;
    uint16_t angle_raw;
    float    current_a;
    float    speed_rpm;
    float    angle_rad;
} QD4310_Feedback;

void QD4310_Init(uint8_t device_id);
void QD4310_SetDeviceID(uint8_t device_id);
uint8_t QD4310_GetDeviceID(void);
void QD4310_SetTimeout(uint32_t timeout_ms);
uint32_t QD4310_GetTimeout(void);

/* UART0 调试输出；不会占用 QD4310 通信所使用的 UART1。 */
void QD4310_DebugWrite(const uint8_t *data, uint32_t length);
void QD4310_DebugPrint(const char *text);
void QD4310_DebugPrintResult(QD4310_Result result);
void QD4310_DebugPrintFeedback(const QD4310_Feedback *feedback);

uint8_t QD4310_CRC8(const uint8_t *data, uint32_t length);

QD4310_Result QD4310_Transfer(QD4310_Command command,
                              uint16_t value_raw,
                              QD4310_Feedback *feedback);

QD4310_Result QD4310_Nop(QD4310_Feedback *feedback);
QD4310_Result QD4310_Enable(QD4310_Feedback *feedback);
QD4310_Result QD4310_Disable(QD4310_Feedback *feedback);
QD4310_Result QD4310_SetCurrent(float current_a, QD4310_Feedback *feedback);
QD4310_Result QD4310_SetSpeed(float speed_rpm, QD4310_Feedback *feedback);
QD4310_Result QD4310_SetAngle(float angle_rad, QD4310_Feedback *feedback);
QD4310_Result QD4310_SetLowSpeed(float speed_rpm, QD4310_Feedback *feedback);
QD4310_Result QD4310_SetStepAngle(float delta_rad, QD4310_Feedback *feedback);
QD4310_Result QD4310_Reboot(QD4310_Feedback *feedback);
QD4310_Result QD4310_SetZero(QD4310_Feedback *feedback);
QD4310_Result QD4310_ClearError(QD4310_Feedback *feedback);

/* STATUS 字节辅助解析: bit0=使能, bit4~7=当前模式。 */
uint8_t QD4310_IsEnabled(const QD4310_Feedback *feedback);
uint8_t QD4310_GetMode(const QD4310_Feedback *feedback);

#ifdef __cplusplus
}
#endif

#endif /* QD4310_H */
