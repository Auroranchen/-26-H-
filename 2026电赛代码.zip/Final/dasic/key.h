/*
 * =========================== key.h ============================
 *  简介：
 *      四个按键的轮询式驱动 + 事件检测。
 *      本项目用到:
 *          PA15 -> 详情页短按: 启动当前要求
 *          PB16 -> 短按: 随时停止小车
 *          PA07 -> 菜单页短按: 切换 OLED 要求
 *          PB14 -> 菜单页进入详情/未运行时从详情返回菜单
 *
 *  硬件(SysConfig 已配为上拉输入, 按下=低电平):
 *          KEY_A15 = GPIOA.15
 *          KEY_B16 = GPIOB.16
 *          KEY_A07 = GPIOA.7
 *          KEY_B14 = GPIOB.14
 *
 *  本模块不依赖中断。主循环每 5~10ms 调用 Key_Scan(dt_ms)，
 *  再用 Key_GetEvent() 查询事件。读取事件后会立即清除；所有按键均在
 *  稳定按下达到消抖阈值时触发一次，按住不重复，松开后可再次触发。
 * ===============================================================
 */
#ifndef KEY_H
#define KEY_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 按键/事件编号 */
typedef enum {
    KEY_START = 0,      /* PA15: 详情页待机时启动 */
    KEY_STOP,           /* PB16: 随时停止 */
    KEY_MODE_NEXT,      /* PA07: 菜单页切换要求 */
    KEY_MODE_CONFIRM,   /* PB14: 进入详情/返回菜单 */
    KEY_EVENT_NUM
} Key_ID;

/* 长按判定时长(毫秒，保留供按键驱动通用逻辑使用) */
#define KEY_LONG_MS     1000

/* 扫描所有按键。dt_ms 为距上次调用的间隔，用于消抖与按住计时。 */
void Key_Scan(uint16_t dt_ms);

/* 查询并清除按键事件。有事件返回 1，否则返回 0。 */
uint8_t Key_GetEvent(Key_ID id);

#ifdef __cplusplus
}
#endif

#endif /* KEY_H */
