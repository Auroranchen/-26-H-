/*
 * ========================== bmi088.c ==========================
 *  BMI088 六轴 IMU 的 SPI 驱动 + 姿态解算实现。
 *  详细协议、接线与用法见 bmi088.h 头部注释。
 *
 *  实现要点：
 *      - SPI 底层: bmi_spi_rw() 收发一个字节(全双工)。
 *      - 片选: 加速度计用 CS1(GPIOB.12), 陀螺仪用 CS2(GPIOB.13), 软件控制。
 *      - 加速度计 SPI 读有“空字节”怪癖: 发完寄存器地址后要先丢弃 1 个字节,
 *        再读真实数据; 陀螺仪没有这个怪癖。
 *      - 初始化按数据手册: 加速度计需软复位 + 上电 + 一次空读锁定 SPI 模式。
 *      - 姿态: 加速度算 Pitch/Roll 的“绝对参考”, 陀螺算“短时变化”,
 *        用互补滤波融合; Yaw 只能靠陀螺积分(无磁力计)。
 * ===============================================================
 */
#include "bmi088.h"
#include "delay.h"
#include "oled.h"
#include <math.h>

/* ---------------- 片选(CS)控制 ----------------
 * 引脚宏由 SysConfig 生成(引脚组 BMI088_CS): CS1=加速度, CS2=陀螺。
 * 低=选中, 高=释放。 */
#define ACC_CS_LOW()    DL_GPIO_clearPins(BMI088_CS_PORT, BMI088_CS_BMI088_CS1_PIN)
#define ACC_CS_HIGH()   DL_GPIO_setPins  (BMI088_CS_PORT, BMI088_CS_BMI088_CS1_PIN)
#define GYR_CS_LOW()    DL_GPIO_clearPins(BMI088_CS_PORT, BMI088_CS_BMI088_CS2_PIN)
#define GYR_CS_HIGH()   DL_GPIO_setPins  (BMI088_CS_PORT, BMI088_CS_BMI088_CS2_PIN)

/* ---------------- BMI088 寄存器地址 ---------------- */
/* 加速度计(ACC)子芯片 */
#define ACC_REG_CHIP_ID     0x00    /* 应读到 0x1E */
#define ACC_REG_X_LSB       0x12    /* X/Y/Z 各 2 字节, 小端, 从此连读 6 字节 */
#define ACC_REG_CONF        0x40    /* 输出速率 + 带宽 */
#define ACC_REG_RANGE       0x41    /* 量程 */
#define ACC_REG_PWR_CONF    0x7C    /* 0x00=active, 0x03=suspend */
#define ACC_REG_PWR_CTRL    0x7D    /* 0x04=加速度计开, 0x00=关 */
#define ACC_REG_SOFTRESET   0x7E    /* 写 0xB6 软复位 */
#define ACC_CHIP_ID_VAL     0x1E

/* 陀螺仪(GYR)子芯片 */
#define GYR_REG_CHIP_ID     0x00    /* 应读到 0x0F */
#define GYR_REG_X_LSB       0x02    /* X/Y/Z 各 2 字节, 小端, 从此连读 6 字节 */
#define GYR_REG_RANGE       0x0F    /* 量程 */
#define GYR_REG_BANDWIDTH   0x10    /* 带宽/输出速率 */
#define GYR_REG_LPM1        0x11    /* 电源模式: 0x00=normal */
#define GYR_REG_SOFTRESET   0x14    /* 写 0xB6 软复位 */
#define GYR_CHIP_ID_VAL     0x0F

#define SOFT_RESET_CMD      0xB6

/* ---------------- 量程/换算常数 ----------------
 * 加速度计: 量程 ±6G, 16 位。每 LSB = 6/32768 g。姿态只用比值, 原始值即可。
 * 陀螺仪:   量程 ±1000 dps, 16 位。每 LSB = 1000/32768 dps ≈ 0.030518。 */
#define GYRO_LSB_TO_DPS     (1000.0f / 32768.0f)
#define RAD_TO_DEG          57.2957795f
#define ALPHA               0.98f   /* 互补滤波系数: 越大越信任陀螺 */

/* ---------------- 内部状态 ---------------- */
static BMI088_Attitude_t s_att      = {0};
static uint32_t          s_last_tick = 0;      /* 上次 Update 的节拍(ms), 求 dt */
static uint8_t           s_first     = 1;      /* 首次 Update: 用加速度直接初始化角度 */

/* 陀螺三轴零偏(静止时的读数, 单位: 原始 LSB)。
 * 静止时陀螺输出并非正好 0, 若不减掉, Yaw 纯积分会一直漂(表现为 Y 不停自增)。 */
static float s_bias_x = 0.0f;
static float s_bias_y = 0.0f;
static float s_bias_z = 0.0f;

/* Yaw 死区(度/秒): 减完零偏后仍有微小噪声, 低于此值视为静止不积分,
 * 进一步抑制 Yaw 漂移。设太大会吃掉缓慢真实转动, 0.1 左右较稳妥。 */
#define YAW_RATE_DEADBAND   0.1f

/* ---------- SPI 收发一个字节(全双工) ---------- */
static uint8_t bmi_spi_rw(uint8_t tx)
{
    DL_SPI_transmitDataBlocking8(BMI088_SPI_0_INST, tx);
    return DL_SPI_receiveDataBlocking8(BMI088_SPI_0_INST);
}

/* ---------- 加速度计: 写寄存器 ---------- */
static void acc_write(uint8_t reg, uint8_t val)
{
    ACC_CS_LOW();
    bmi_spi_rw(reg & 0x7F);      /* bit7=0 表示写 */
    bmi_spi_rw(val);
    ACC_CS_HIGH();
}

/* ---------- 加速度计: 连读寄存器(含 1 个空字节怪癖) ---------- */
static void acc_read(uint8_t reg, uint8_t *buf, uint8_t len)
{
    ACC_CS_LOW();
    bmi_spi_rw(reg | 0x80);      /* bit7=1 表示读 */
    bmi_spi_rw(0x00);            /* 加速度计 SPI 读: 丢弃 1 个空字节 */
    for (uint8_t i = 0; i < len; i++) {
        buf[i] = bmi_spi_rw(0x00);
    }
    ACC_CS_HIGH();
}

/* ---------- 陀螺仪: 写寄存器 ---------- */
static void gyr_write(uint8_t reg, uint8_t val)
{
    GYR_CS_LOW();
    bmi_spi_rw(reg & 0x7F);
    bmi_spi_rw(val);
    GYR_CS_HIGH();
}

/* ---------- 陀螺仪: 连读寄存器(无空字节) ---------- */
static void gyr_read(uint8_t reg, uint8_t *buf, uint8_t len)
{
    GYR_CS_LOW();
    bmi_spi_rw(reg | 0x80);
    for (uint8_t i = 0; i < len; i++) {
        buf[i] = bmi_spi_rw(0x00);
    }
    GYR_CS_HIGH();
}

uint8_t BMI088_Init(void)
{
    uint8_t acc_id, gyr_id;
    uint8_t gb[6];

    /* 0. 两个 CS 先拉高释放(SysConfig 默认拉低, 这里纠正) */
    ACC_CS_HIGH();
    GYR_CS_HIGH();
    Delay_Ms(5);

    /* ================= 加速度计 ================= */
    /* 上电后加速度计默认 I2C 模式, 需先做一次“空 SPI 读”把它切到 SPI 模式 */
    acc_read(ACC_REG_CHIP_ID, &acc_id, 1);
    Delay_Ms(1);

    /* 软复位, 等待重启 */
    acc_write(ACC_REG_SOFTRESET, SOFT_RESET_CMD);
    Delay_Ms(50);

    /* 复位后又回到 I2C 模式, 再空读一次锁定 SPI */
    acc_read(ACC_REG_CHIP_ID, &acc_id, 1);
    Delay_Ms(1);
    acc_read(ACC_REG_CHIP_ID, &acc_id, 1);   /* 这次才是有效 ID */

    /* 上电: 先开加速度计, 再进入 active 模式。
     * 加速度计从关到开需要较长稳定时间(手册 ~50ms), 等太短会读到恒定/旧值,
     * 表现为 Pitch/Roll 不随倾斜变化。 */
    acc_write(ACC_REG_PWR_CTRL, 0x04);       /* accel on */
    Delay_Ms(50);
    acc_write(ACC_REG_PWR_CONF, 0x00);       /* active(退出挂起) */
    Delay_Ms(5);

    /* 输出速率 100Hz + 正常带宽(0xA8), 量程 ±6G(0x01) */
    acc_write(ACC_REG_CONF,  0xA8);
    acc_write(ACC_REG_RANGE, 0x01);
    Delay_Ms(5);

    /* ================= 陀螺仪 ================= */
    gyr_write(GYR_REG_SOFTRESET, SOFT_RESET_CMD);
    Delay_Ms(30);

    gyr_read(GYR_REG_CHIP_ID, &gyr_id, 1);   /* 应为 0x0F */

    gyr_write(GYR_REG_RANGE,     0x01);      /* ±1000 dps */
    gyr_write(GYR_REG_BANDWIDTH, 0x07);      /* ODR 100Hz / BW 32Hz */
    gyr_write(GYR_REG_LPM1,      0x00);      /* normal 模式 */
    Delay_Ms(30);

    /* ================= 陀螺零偏校准(务必保持静止!) =================
     * 静止取 N 次平均作为三轴零偏, 之后每次读数都减掉。
     * 这是消除“Yaw 不停自增”的关键: Yaw 纯积分, 不减零偏就会一直漂。 */
    {
        float bx = 0.0f, by = 0.0f, bz = 0.0f;
        const int N = 300;
        for (int i = 0; i < N; i++) {
            gyr_read(GYR_REG_X_LSB, gb, 6);
            bx += (int16_t)(gb[0] | (gb[1] << 8));
            by += (int16_t)(gb[2] | (gb[3] << 8));
            bz += (int16_t)(gb[4] | (gb[5] << 8));
            Delay_Ms(2);
        }
        s_bias_x = bx / N;
        s_bias_y = by / N;
        s_bias_z = bz / N;
    }

    /* 复位解算状态 */
    s_att.yaw = s_att.pitch = s_att.roll = 0.0f;
    s_first     = 1;
    s_last_tick = Delay_GetTick();

    /* 两颗子芯片 ID 都对才算成功 */
    return (acc_id == ACC_CHIP_ID_VAL && gyr_id == GYR_CHIP_ID_VAL) ? 1 : 0;
}

void BMI088_Update(void)
{
    uint8_t ab[6], gb[6];

    /* ---- 读原始六轴(小端, 有符号) ---- */
    acc_read(ACC_REG_X_LSB, ab, 6);
    gyr_read(GYR_REG_X_LSB, gb, 6);

    int16_t ax = (int16_t)(ab[0] | (ab[1] << 8));
    int16_t ay = (int16_t)(ab[2] | (ab[3] << 8));
    int16_t az = (int16_t)(ab[4] | (ab[5] << 8));

    int16_t gx = (int16_t)(gb[0] | (gb[1] << 8));
    int16_t gy = (int16_t)(gb[2] | (gb[3] << 8));
    int16_t gz = (int16_t)(gb[4] | (gb[5] << 8));

    /* ---- 加速度算 Pitch/Roll 的绝对参考(原始值即可, 比例会约掉) ---- */
    float faz = (float)az;
    float fax = (float)ax;
    float fay = (float)ay;
    float roll_acc  = atan2f(fay, faz) * RAD_TO_DEG;
    float pitch_acc = atan2f(-fax, sqrtf(fay * fay + faz * faz)) * RAD_TO_DEG;

    /* ---- 陀螺角速度(度/秒), 先减掉静止零偏 ---- */
    float gx_dps = (gx - s_bias_x) * GYRO_LSB_TO_DPS;    /* 绕 X 轴 = roll 速率 */
    float gy_dps = (gy - s_bias_y) * GYRO_LSB_TO_DPS;    /* 绕 Y 轴 = pitch 速率 */
    float gz_dps = (gz - s_bias_z) * GYRO_LSB_TO_DPS;    /* 绕 Z 轴 = yaw 速率 */

    /* Yaw 死区: 去掉零偏后的残余噪声不积分, 抑制静止漂移 */
    if (gz_dps > -YAW_RATE_DEADBAND && gz_dps < YAW_RATE_DEADBAND) {
        gz_dps = 0.0f;
    }

    /* ---- 求真实 dt(秒), 基于 1ms 节拍, 无符号相减抗回绕 ---- */
    uint32_t now = Delay_GetTick();
    float dt = (now - s_last_tick) * 0.001f;
    s_last_tick = now;
    if (dt <= 0.0f || dt > 0.5f) {
        dt = 0.01f;     /* 异常(首次/长时间未调用)时给个保守值 */
    }

    if (s_first) {
        /* 首帧: 直接用加速度姿态初始化, 避免从 0 缓慢收敛 */
        s_att.roll  = roll_acc;
        s_att.pitch = pitch_acc;
        s_att.yaw   = 0.0f;
        s_first     = 0;
    } else {
        /* 互补滤波: 陀螺积分(短时准) + 加速度参考(长时不漂) */
        s_att.roll  = ALPHA * (s_att.roll  + gx_dps * dt) + (1.0f - ALPHA) * roll_acc;
        s_att.pitch = ALPHA * (s_att.pitch + gy_dps * dt) + (1.0f - ALPHA) * pitch_acc;
        s_att.yaw  += gz_dps * dt;      /* 无磁力计, 只能积分, 会缓慢漂移 */
    }

    /* Yaw 归一化到 0~360 */
    if (s_att.yaw < 0.0f)    s_att.yaw += 360.0f;
    if (s_att.yaw >= 360.0f) s_att.yaw -= 360.0f;
}

void BMI088_GetAttitude(BMI088_Attitude_t *out)
{
    if (out == NULL) return;
    out->yaw   = s_att.yaw;
    out->pitch = s_att.pitch;
    out->roll  = s_att.roll;
}

/* 在 OLED 上显示一个带正负号、两位小数的角度值。
 * 例如 -12.34 显示为 "-012.34"(整数补足3位, 便于对齐)。 */
static void oled_show_angle(uint8_t x, uint8_t y, float val)
{
    uint8_t neg = 0;
    if (val < 0) { neg = 1; val = -val; }

    uint32_t scaled = (uint32_t)(val * 100.0f + 0.5f);  /* 放大100取整, 含四舍五入 */
    uint32_t ipart  = scaled / 100;
    uint32_t fpart  = scaled % 100;

    OLED_ShowChar(x,      y, neg ? '-' : '+', 16);
    OLED_ShowNum (x + 8,  y, ipart, 3, 16);
    OLED_ShowChar(x + 32, y, '.', 16);
    OLED_ShowNum (x + 40, y, fpart, 2, 16);
}

void BMI088_ShowOnOLED(uint8_t x, uint8_t y)
{
    BMI088_Attitude_t att;
    BMI088_GetAttitude(&att);

    OLED_ShowString(x, y,      (u8 *)"Y:", 16);
    oled_show_angle(x + 24, y,      att.yaw);
    OLED_ShowString(x, y + 16, (u8 *)"P:", 16);
    oled_show_angle(x + 24, y + 16, att.pitch);
    OLED_ShowString(x, y + 32, (u8 *)"R:", 16);
    oled_show_angle(x + 24, y + 32, att.roll);
}
