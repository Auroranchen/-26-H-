/*
 * ========================== pca9685.c ==========================
 *  PCA9685 16路PWM/舵机驱动实现 (I2C0, 地址0x40)。
 *  详细使用说明与接线见 pca9685.h 头部注释。
 *
 *  实现要点：
 *      - I2C 时序复用与 oled.c 相同的硬件 I2C 写法(Steering_INST)。
 *      - 频率换算(数据手册): prescale = 25MHz/(4096*freq) - 1。
 *      - 舵机: 50Hz 周期20ms 对应 4096 计数, 即每微秒 ≈ 0.2048 计数。
 * ===============================================================
 */
#include "pca9685.h"
#include "delay.h"

/* ---- PCA9685 寄存器地址 ---- */
#define PCA9685_MODE1       0x00
#define PCA9685_PRESCALE    0xFE
#define PCA9685_LED0_ON_L   0x06    /* 通道0起始, 每通道占4字节 */

#define PCA9685_OSC_CLOCK   25000000UL  /* 内部振荡器 25MHz */

/* 向 PCA9685 的某个寄存器写一个字节 */
static void PCA9685_WriteReg(uint8_t reg, uint8_t val)
{
    uint8_t txData[2];
    txData[0] = reg;
    txData[1] = val;

    /* 1. 等待 I2C 空闲 */
    while (!(DL_I2C_getControllerStatus(Steering_INST) & DL_I2C_CONTROLLER_STATUS_IDLE));
    /* 2. 填入发送 FIFO */
    DL_I2C_fillControllerTXFIFO(Steering_INST, txData, 2);
    /* 3. 启动传输(写方向, 2字节) */
    DL_I2C_startControllerTransfer(Steering_INST, PCA9685_ADDR,
                                   DL_I2C_CONTROLLER_DIRECTION_TX, 2);
    /* 4. 等待硬件状态机启动 */
    while (!(DL_I2C_getControllerStatus(Steering_INST) & DL_I2C_CONTROLLER_STATUS_BUSY_BUS));
    /* 5. 等待传输真正完成 */
    while (!(DL_I2C_getControllerStatus(Steering_INST) & DL_I2C_CONTROLLER_STATUS_IDLE));
}

/* 设置某通道 PWM: 在 on 计数点拉高, 在 off 计数点拉低 (0~4095) */
void PCA9685_SetPWM(uint8_t ch, uint16_t on, uint16_t off)
{
    if (ch > 15) return;
    uint8_t base = PCA9685_LED0_ON_L + 4 * ch;
    PCA9685_WriteReg(base + 0, on & 0xFF);          /* ON_L  */
    PCA9685_WriteReg(base + 1, (on >> 8) & 0x0F);   /* ON_H  */
    PCA9685_WriteReg(base + 2, off & 0xFF);         /* OFF_L */
    PCA9685_WriteReg(base + 3, (off >> 8) & 0x0F);  /* OFF_H */
}

/* 设置 PWM 频率(Hz)。改频率必须让芯片进入 SLEEP 才能写 PRESCALE。 */
void PCA9685_SetFreq(float freq_hz)
{
    /* prescale = round(osc / (4096 * freq)) - 1 */
    uint32_t prescale = (uint32_t)((PCA9685_OSC_CLOCK / (4096.0f * freq_hz)) + 0.5f) - 1;

    PCA9685_WriteReg(PCA9685_MODE1, 0x10);          /* 进入 SLEEP */
    PCA9685_WriteReg(PCA9685_PRESCALE, (uint8_t)prescale);
    PCA9685_WriteReg(PCA9685_MODE1, 0x00);          /* 退出 SLEEP */
    Delay_Ms(1);                                    /* 等振荡器稳定(>500us) */
    PCA9685_WriteReg(PCA9685_MODE1, 0xA0);          /* 自动递增 + 重启 */
}

void PCA9685_Init(void)
{
    /* 使能引脚 STEERING_EN_B11: 低电平使能, 拉低以开启舵机供电/使能 */
    DL_GPIO_clearPins(STEERING_EN_PORT, STEERING_EN_STEERING_EN_B11_PIN);

    Delay_Ms(10);
    PCA9685_WriteReg(PCA9685_MODE1, 0x00);          /* 正常模式 */
    PCA9685_SetFreq(50.0f);                          /* 舵机标准 50Hz */
}

/* 让某通道输出指定高电平脉宽(微秒)。
 * 50Hz 时周期 20000us 对应 4096 计数, 故 count = us * 4096 / 20000。 */
void Servo_SetPulse(uint8_t ch, uint16_t us)
{
    uint32_t off = ((uint32_t)us * 4096UL) / 20000UL;
    if (off > 4095) off = 4095;
    PCA9685_SetPWM(ch, 0, (uint16_t)off);
}

/* 角度(0~180) -> 脉宽(SERVO_MIN_US~SERVO_MAX_US) -> 输出 */
void Servo_SetAngle(uint8_t ch, uint8_t angle)
{
    if (angle > 180) angle = 180;
    uint16_t us = SERVO_MIN_US +
                  ((uint32_t)(SERVO_MAX_US - SERVO_MIN_US) * angle) / 180;
    Servo_SetPulse(ch, us);
}
