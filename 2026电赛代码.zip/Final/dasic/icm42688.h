/*
 * ========================== icm42688.h ==========================
 *  简介：
 *      汇电籽-601 姿态模块(内含 ICM42688 IMU)串口驱动。
 *      模块通过 UART 主动上报姿态角(Yaw/Pitch/Roll), 本驱动负责：
 *          - 上电初始化(复位/校准/设为仅姿态模式/启动上报)
 *          - 在 UART 中断里按协议帧解析出姿态角
 *          - 提供非阻塞查询接口, 供主循环刷到 OLED
 *
 *  通信协议(见《汇电籽-601 通信协议说明书》)：
 *      波特率 115200, 8N1, 小端。帧格式：
 *          AA 55 | DevID(0x60) | CMD | LEN | DATA... | CS
 *      校验和 CS = (DevID+CMD+LEN+DATA各字节) & 0xFF。
 *      本驱动用【模式1 仅姿态, LEN=6】: DATA = [Yaw(u16), Pitch(i16), Roll(i16)]
 *      角度均放大 100 倍传输, 除以 100 还原真实角度。
 *
 *  硬件接线 (MSPM0G3507, 由 SysConfig 配置为 UART_2)：
 *      模块 T(TX) -> MCU RX = GPIOA.22   (UART2_RX)
 *      模块 R(RX) -> MCU TX = GPIOB.15   (UART2_TX)
 *      V -> 5V      G -> GND
 *      注意: 模块的 T 接单片机 RX, 模块的 R 接单片机 TX(交叉接)。
 *
 *  使用方法：
 *      1. 包含头文件：
 *              #include "icm42688.h"
 *
 *      2. 上电后先芯片初始化, 再初始化模块：
 *              SYSCFG_DL_init();       // UART2 已在此配好(含RX中断)
 *              ICM42688_Init();        // 复位/校准/仅姿态模式/启动上报
 *
 *      3. 主循环里非阻塞取数据(有新帧才为真)：
 *              if (ICM42688_IsUpdated()) {
 *                  Attitude_t att;
 *                  ICM42688_GetAttitude(&att);   // 读走并清标志
 *                  // att.yaw / att.pitch / att.roll 即真实角度(浮点)
 *              }
 *
 *      4. 直接刷到 OLED(内部处理正负号与小数)：
 *              ICM42688_ShowOnOLED(0, 0);   // 从 OLED (x=0,y=0) 起显示三行
 *
 *  依赖：
 *      - delay.h / delay.c   (初始化里的固定等待)
 *      - oled.h              (ICM42688_ShowOnOLED 用到)
 *      - UART_2 (SysConfig, 已使能 RX 中断)
 * ===============================================================
 */
#ifndef ICM42688_H
#define ICM42688_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 解析后的姿态角(真实角度, 单位: 度) */
typedef struct {
    float yaw;      /* 航向 0 ~ 360   */
    float pitch;    /* 俯仰 -180 ~ 180 */
    float roll;     /* 横滚 -180 ~ 180 */
} Attitude_t;

/*
 * ICM42688_Init       - 初始化模块: 复位/校准, 设为仅姿态模式并启动上报,
 *                       同时打开 UART2 的 NVIC 接收中断
 * ICM42688_IsUpdated  - 是否收到并解析出一帧新姿态数据(非阻塞查询)
 * ICM42688_GetAttitude- 取出最新姿态角(拷贝到 out), 并清除“已更新”标志
 * ICM42688_ShowOnOLED - 把最新姿态角(带正负号/两位小数)显示到 OLED
 *                       (x,y) 为第一行左上角, 内部按16号字往下排三行
 */
void    ICM42688_Init(void);
uint8_t ICM42688_IsUpdated(void);
void    ICM42688_GetAttitude(Attitude_t *out);
void    ICM42688_ShowOnOLED(uint8_t x, uint8_t y);

/*
 * ICM42688_Calibrate - 触发模块重新校准(协议 0x10 指令: AA 55 60 10 00 70)。
 *                      长按 A07 按键时调用。校准期间应保持模块静止水平放置。
 *                      注意: 这是阻塞发送 6 字节, 发完即返回(校准由模块内部完成)。
 */
void    ICM42688_Calibrate(void);

#ifdef __cplusplus
}
#endif

#endif /* ICM42688_H */
