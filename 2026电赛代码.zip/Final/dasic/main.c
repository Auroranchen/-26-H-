/*
 * ============================ main.c ============================
 *  H 题 - 要求 2:
 *    小车置于 A 点, 按键启动后沿黑线顺时针行驶一圈并停回 A 点,
 *    计时停止并显示行驶总时间。要求: 总时间 <= 20s, 停车偏差 <= 2cm。
 *
 *  OLED 菜单提供要求 2/3/4/5/6。EVENT3 进入详情页后等待 PA15，
 *  启动时保持小车静止，并通过 UART2 向摆杆控制板发送一次摆球指令。
 *
 *  EVENT2 启动后先离开起点，12s 后才允许识别返回 A；8 路灰度压线
 *  总数严格 >3 并连续两帧即确认 A，再按本圈时间比例前进约 32cm，
 *  让车尾到 A 后停车。
 *
 *  EVENT2 不使用编码器里程或 20s 定时作为自动停车条件，不改变速度/PID。
 *  编码器仅保留为结果页诊断；EVENT4 独立按 1.5m 里程到 B，EVENT5/6
 *  保留原有整圈逻辑。
 * ===============================================================
 */

#include "ti_msp_dl_config.h"
#include "delay.h"
#include "oled.h"
#include "led.h"
#include "gray.h"
#include "motor.h"
#include "control.h"
#include "key.h"
#include "CarStateSend.h"

/* ==================== 赛道 / 标定参数 ==================== */

/* 一圈周长 6.142m；EVENT2 用它和 320mm 车长计算动态补偿时间。 */
#define LAP_LENGTH_M            6.142f

/* EVENT4/5/6 现有里程参数，EVENT2 不使用。 */
#define ODO_PULSE_PER_METER     1800

/* EVENT4 的 AB 距离为 1.5m，里程单位沿用左右轮编码器累计脉冲和。 */
#define EVENT4_DISTANCE_MM      1500
#define ODO_EVENT4_GATE \
    ((int32_t)(((int32_t)EVENT4_DISTANCE_MM * ODO_PULSE_PER_METER + 500) / 1000))

/* EVENT4/5/6 沿用原找线门限。 */
#define ODO_SEEK_GATE   ((int32_t)(LAP_LENGTH_M * 0.70f * ODO_PULSE_PER_METER))
/* 2) 减速门限: 跑够周长的 88% 之后, 提前把巡线基速降下来, 便于精确停车 */
#define ODO_SLOW_GATE   ((int32_t)(LAP_LENGTH_M * 0.88f * ODO_PULSE_PER_METER))

/* 临近终点的减速百分比(相对正常巡线基速) */
#define SLOW_SCALE_PCT          40

#define DISPLAY_PERIOD_MS       10U
#define EVENT3_TIME_LIMIT_MS    5000U
#define EVENT4_TIME_LIMIT_MS    7500U
#define EVENT5_TIME_LIMIT_MS    25000U
#define REQUIREMENT_COUNT       5U
#define TIME_MAX_MS             99990U

static const uint8_t s_requirements[REQUIREMENT_COUNT] = {2, 3, 4, 5, 6};

/* ==================== OLED 页面 / 上层流程状态 ==================== */

typedef enum {
    UI_PAGE_MENU = 0,
    UI_PAGE_DETAIL
} UiPage;

typedef enum {
    RUN_IDLE = 0,   /* 待命, 等启动键 */
    RUN_RUNNING,    /* 事件执行/计时中 */
    RUN_FINISHED    /* 已停止, 显示结果 */
} RunState;

static uint8_t run_is_active(RunState state)
{
    return state == RUN_RUNNING;
}

static uint32_t s_last_display_centiseconds = 0xFFFFFFFFU;

static void draw_event_label(uint8_t x, uint8_t y, uint8_t requirement)
{
    OLED_ShowString(x, y, (u8 *)"EVENT", 16);
    OLED_ShowNum(x + 40, y, requirement, 1, 16);
}

static void draw_menu_page(uint8_t selected)
{
    static const uint8_t item_x[REQUIREMENT_COUNT] = {8, 72, 8, 72, 8};
    static const uint8_t item_y[REQUIREMENT_COUNT] = {0, 0, 24, 24, 48};
    uint8_t i;

    OLED_ClearBuffer();
    for (i = 0; i < REQUIREMENT_COUNT; i++) {
        draw_event_label(item_x[i], item_y[i], s_requirements[i]);
    }
    OLED_ShowChar(item_x[selected] - 8U, item_y[selected], '>', 16);
    OLED_Refresh();
}

static uint32_t clamp_display_ms(uint32_t ms)
{
    return (ms > TIME_MAX_MS) ? TIME_MAX_MS : ms;
}

static void draw_time_value(uint32_t ms, uint8_t partial_refresh)
{
    uint32_t shown_ms = clamp_display_ms(ms);
    uint32_t centiseconds = shown_ms / 10U;

    if (partial_refresh && centiseconds == s_last_display_centiseconds) {
        return;
    }

    OLED_ShowNum(40, 44, shown_ms / 1000U, 2, 16);
    OLED_ShowChar(56, 44, '.', 16);
    OLED_ShowNum(64, 44, (shown_ms % 1000U) / 10U, 2, 16);
    OLED_ShowChar(80, 44, 's', 16);
    s_last_display_centiseconds = centiseconds;

    if (partial_refresh) {
        OLED_RefreshArea(40, 87, 5, 7);
    }
}

static void draw_detail_page(uint8_t requirement, uint32_t ms)
{
    OLED_ClearBuffer();
    OLED_ShowString(0, 0, (u8 *)"MODE:", 16);
    draw_event_label(40, 0, requirement);
    OLED_ShowString(0, 20, (u8 *)"READY:PA15 STOP:PB16", 12);
    OLED_ShowString(0, 44, (u8 *)"TIME:", 16);
    s_last_display_centiseconds = 0xFFFFFFFFU;
    draw_time_value(ms, 0);
    OLED_Refresh();
}

static void draw_event3_status(const char *status, uint32_t ms)
{
    OLED_ClearBuffer();
    OLED_ShowString(0, 0, (u8 *)"EVENT3 LOCAL", 16);
    OLED_ShowString(0, 20, (u8 *)status, 16);
    OLED_ShowString(0, 44, (u8 *)"TIME:", 16);
    s_last_display_centiseconds = 0xFFFFFFFFU;
    draw_time_value(ms, 0);
    OLED_Refresh();
}

static const char *event2_reason_text(ControlEvent2StopReason reason)
{
    switch (reason) {
        case CONTROL_EVENT2_STOP_A_TAIL: return "A";
        case CONTROL_EVENT2_STOP_MANUAL: return "MAN";
        default:                           return "NONE";
    }
}

static void draw_event2_result(uint32_t ms)
{
    OLED_ClearBuffer();
    OLED_ShowString(0, 0, (u8 *)"EVENT2 DONE", 16);
    OLED_ShowString(0, 16, (u8 *)"RS:", 16);
    OLED_ShowString(24, 16,
                    (u8 *)event2_reason_text(Control_GetEvent2StopReason()), 16);
    OLED_ShowString(0, 32, (u8 *)"A:", 16);
    OLED_ShowNum(16, 32, Control_GetEvent2DetectMs() / 10U, 4, 16);
    OLED_ShowString(56, 32, (u8 *)"D:", 16);
    OLED_ShowNum(72, 32, Control_GetEvent2TailDelayMs(), 4, 16);
    OLED_ShowString(0, 48, (u8 *)"T:", 16);
    OLED_ShowNum(16, 48, clamp_display_ms(ms) / 1000U, 2, 16);
    OLED_ShowChar(32, 48, '.', 16);
    OLED_ShowNum(40, 48, (clamp_display_ms(ms) % 1000U) / 10U, 2, 16);
    OLED_ShowChar(56, 48, 's', 16);
    OLED_Refresh();
}

int main(void)
{
    SYSCFG_DL_init();
    CarStateSend_Init();

    /* 第 2 题纯循迹跑圈不初始化姿态模块，避免未接模块时阻塞启动。 */
    OLED_Init();
    Delay_TimerStart();     /* 1ms 系统节拍, 计时/非阻塞用 */
    Motor_Init();           /* PWM + 编码器中断 */
    Motor_StopAll();        /* 上电确保电机静止 */
    Control_Start();        /* 启动控制环, 但未 Run 不驱动电机 */

    UiPage ui_page = UI_PAGE_MENU;
    RunState state = RUN_IDLE;
    uint8_t selected_requirement = 0;
    uint8_t detail_requirement = s_requirements[0];
    uint32_t t_start = 0;
    uint32_t t_total = 0;
    uint32_t t_key = Delay_GetTick();
    uint32_t t_display = t_key;

    draw_menu_page(selected_requirement);

    while (1)
    {
        uint32_t now = Delay_GetTick();

        /* 按键扫描固定约 5ms 一次，PB16 始终保持最高急停优先级。 */
        if (now - t_key >= 5U) {
            Key_Scan((uint16_t)(now - t_key));
            t_key = now;

            uint8_t stop_pressed = Key_GetEvent(KEY_STOP);
            if (stop_pressed) {
                Control_Stop();
                if (run_is_active(state)) {
                    t_total = now - t_start;
                    state = RUN_FINISHED;
                    if (detail_requirement == 2) {
                        draw_event2_result(t_total);
                    } else if (detail_requirement == 3) {
                        draw_event3_status("MAN STOP", t_total);
                    } else {
                        draw_time_value(t_total, 1);
                    }
                }
            }

            if (!stop_pressed && !run_is_active(state)) {
                if (ui_page == UI_PAGE_MENU) {
                    if (Key_GetEvent(KEY_MODE_NEXT)) {
                        selected_requirement++;
                        if (selected_requirement >= REQUIREMENT_COUNT) {
                            selected_requirement = 0;
                        }
                        draw_menu_page(selected_requirement);
                    }

                    if (Key_GetEvent(KEY_MODE_CONFIRM)) {
                        detail_requirement = s_requirements[selected_requirement];
                        t_total = 0;
                        ui_page = UI_PAGE_DETAIL;

                        state = RUN_IDLE;
                        draw_detail_page(detail_requirement, 0);
                    }

                    /* 菜单页不允许启动，读取并丢弃事件以防切页后误启动。 */
                    (void)Key_GetEvent(KEY_START);
                } else {
                    /* 详情页 PA07 无功能。 */
                    (void)Key_GetEvent(KEY_MODE_NEXT);

                    if (Key_GetEvent(KEY_MODE_CONFIRM)) {
                        state = RUN_IDLE;
                        t_total = 0;
                        ui_page = UI_PAGE_MENU;
                        draw_menu_page(selected_requirement);
                    } else if (Key_GetEvent(KEY_START)) {
                        if (detail_requirement == 2) {
                            Control_RunEvent2();
                        } else if (detail_requirement == 3) {
                            /* EVENT3 仅在 PA15 启动时发送一次，小车始终保持刹车。 */
                            Control_Stop();
                            t_start = now;
                            t_total = 0;
                            t_display = now;
                            if (CarStateSend_Send(CARSTATE_SEND_MOTION_STOP,
                                                  CARSTATE_SEND_MODE_EVENT3)) {
                                state = RUN_RUNNING;
                                draw_event3_status("TIME WINDOW", 0);
                            } else {
                                state = RUN_FINISHED;
                                draw_event3_status("TX ERR", 0);
                            }
                            continue;
                        } else if (detail_requirement == 4) {
                            (void)CarStateSend_Send(CARSTATE_SEND_MOTION_START,
                                                    CARSTATE_SEND_MODE_EVENT4);
                            Control_RunEvent4();
                        } else if (detail_requirement == 5) {
                            (void)CarStateSend_Send(CARSTATE_SEND_MOTION_START,
                                                    CARSTATE_SEND_MODE_EVENT5);
                            Control_RunEvent5();
                        } else if (detail_requirement == 6) {
                            (void)CarStateSend_Send(CARSTATE_SEND_MOTION_START,
                                                    CARSTATE_SEND_MODE_EVENT6);
                            Control_RunEvent5();
                        } else {
                            continue;
                        }
                        t_start = now;
                        t_total = 0;
                        state = RUN_RUNNING;
                        t_display = now;
                        draw_time_value(0, 1);
                    }
                }
            } else {
                /* 运行期间 PA07、PB14、PA15 均不执行任何功能。 */
                (void)Key_GetEvent(KEY_MODE_NEXT);
                (void)Key_GetEvent(KEY_MODE_CONFIRM);
                (void)Key_GetEvent(KEY_START);
            }
        }

        /* EVENT2 的离开起点、12s武装、A点识别和车尾时间补偿均在
         * 100Hz 控制中断完成；OLED 阻塞不会延迟实际停车。 */
        if (state == RUN_RUNNING && detail_requirement == 2) {
            if (Control_GetEvent2State() == CONTROL_EVENT2_DONE) {
                uint32_t finish_tick = Control_GetEvent2FinishTick();
                t_total = finish_tick - t_start;
                state = RUN_FINISHED;
                draw_event2_result(t_total);
            }
        }

        /* EVENT3 只维护本地 5s 时间窗口，小车控制环始终保持停止。
         * 当前单向协议不提供 STM32 完成或稳定状态反馈。 */
        if (state == RUN_RUNNING && detail_requirement == 3) {
            uint32_t event3_elapsed = now - t_start;

            if (event3_elapsed >= EVENT3_TIME_LIMIT_MS) {
                Control_Stop();
                t_total = EVENT3_TIME_LIMIT_MS;
                state = RUN_FINISHED;
                draw_event3_status("TIME END", t_total);
            }
        }

        /* EVENT4 到达 1.5m 或运行满 7.5s 时自动停车，不参与整圈逻辑。 */
        if (state == RUN_RUNNING && detail_requirement == 4) {
            uint32_t event4_elapsed = now - t_start;
            if (Control_GetOdo() >= ODO_EVENT4_GATE ||
                event4_elapsed >= EVENT4_TIME_LIMIT_MS) {
                Control_Stop();
                t_total = event4_elapsed;
                state = RUN_FINISHED;
                draw_time_value(t_total, 1);
            }
        }

        /* EVENT5/6 使用 EVENT4 的速度和 PID，沿同一黑线持续循迹；达到
         * EVENT5_TIME_LIMIT_MS 后自动停车并定格计时。 */
        if (state == RUN_RUNNING &&
            (detail_requirement == 5 || detail_requirement == 6)) {
            uint32_t event56_elapsed = now - t_start;
            if (event56_elapsed >= EVENT5_TIME_LIMIT_MS) {
                Control_Stop();
                t_total = event56_elapsed;
                state = RUN_FINISHED;
                draw_time_value(t_total, 1);
            }
        }

        /* 跑动中每 10ms 更新一次百分秒；停止后由状态切换处更新并定格。 */
        if (run_is_active(state) && now - t_display >= DISPLAY_PERIOD_MS) {
            draw_time_value(now - t_start, 1);
            t_display = now;
        }
    }
}
