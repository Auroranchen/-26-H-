/*
 * ========================== pca9685.h ==========================
 *  简介：
 *      PCA9685 16 路 PWM 驱动芯片(I2C)驱动, 本板用其中 12 路接舵机。
 *      PCA9685 内部 12bit(0~4095)PWM, 全部通道共用同一频率;
 *      驱动舵机时统一设为 50Hz(周期20ms), 用高电平脉宽表示角度。
 *
 *  硬件接线 (MSPM0G3507, 由 SysConfig 配置)：
 *      Steering_INST = I2C0    从机地址 = 0x40   总线 100kHz
 *      SDA  ->  GPIOA.0   (PINCM1, I2C0_SDA)
 *      SCL  ->  GPIOA.1   (PINCM2, I2C0_SCL)
 *      V+   ->  舵机电源(5~6V, 大电流, 勿用板子3.3V直供舵机)
 *      VCC  ->  3.3V(逻辑)     GND -> 共地
 *
 *  使用方法：
 *      1. 包含头文件：
 *              #include "pca9685.h"
 *
 *      2. 上电后先芯片初始化, 再初始化 PCA9685(设为50Hz)：
 *              SYSCFG_DL_init();       // I2C0已在此配好
 *              PCA9685_Init();         // 复位并设频率50Hz(舵机用)
 *
 *      3. 控制舵机(通道 0~11, 角度 0~180 度)：
 *              Servo_SetAngle(0, 90);      // 0号舵机转到90度
 *              Servo_SetAngle(5, 0);       // 5号舵机转到0度
 *              Servo_SetAngle(11, 180);    // 11号舵机转到180度
 *
 *      进阶(直接控制脉宽/占空比)：
 *              Servo_SetPulse(0, 1500);    // 0号通道输出1500us脉宽
 *              PCA9685_SetPWM(3, 0, 2048); // 通道3, 从0计到2048点亮(约50%)
 *
 *  参数约定：
 *      - 通道 ch : 0~15 (舵机用 0~11)
 *      - 角度 angle : 0~180 (度)
 *      - 脉宽 us : 舵机通常 500(0°) ~ 2500(180°) 微秒
 *
 *  依赖：
 *      - 延时函数 Delay_Ms() (来自 delay.h / delay.c)
 * ===============================================================
 */
#ifndef PCA9685_H
#define PCA9685_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- 从机地址(7位, A0~A5全接地时为0x40) ---- */
#define PCA9685_ADDR        0x40

/* ---- 舵机脉宽范围(微秒), 不同舵机可微调 ---- */
#define SERVO_MIN_US        500     /* 对应 0 度   */
#define SERVO_MAX_US        2500    /* 对应 180 度 */

/*
 * PCA9685_Init   - 复位芯片并把 PWM 频率设为 50Hz(舵机标准), 上电只需调用一次
 * PCA9685_SetFreq- 设置 PWM 频率(Hz), 一般用 50; 内部由 PCA9685_Init 调用
 * PCA9685_SetPWM - 底层: 设置某通道的 on/off 计数点(0~4095)
 * Servo_SetPulse - 让某通道输出指定高电平脉宽(微秒)
 * Servo_SetAngle - 让某通道舵机转到指定角度(0~180度)
 */
void PCA9685_Init(void);
void PCA9685_SetFreq(float freq_hz);
void PCA9685_SetPWM(uint8_t ch, uint16_t on, uint16_t off);
void Servo_SetPulse(uint8_t ch, uint16_t us);
void Servo_SetAngle(uint8_t ch, uint8_t angle);

#ifdef __cplusplus
}
#endif

#endif /* PCA9685_H */
