/*
 * =========================== qd4310.c ===========================
 *  QD4310 UART 协议驱动实现。接线、协议和用法见 qd4310.h。
 * ===============================================================
 */
#include "qd4310.h"
#include "delay.h"
#include <stddef.h>

#define QD4310_CONTROL_SIZE       5U
#define QD4310_FEEDBACK_SIZE     10U
#define QD4310_CURRENT_FS_A      10.0f
#define QD4310_SPEED_FS_RPM    1000.0f
#define QD4310_SIGNED_FS       32767.0f
#define QD4310_UNSIGNED_FS     65535.0f

static uint8_t  s_device_id = QD4310_DEFAULT_ID;
static uint32_t s_timeout_ms = QD4310_RX_TIMEOUT_MS;
static uint8_t  s_busy = 0;

static void debug_write_char(char value)
{
    DL_UART_Main_transmitDataBlocking(QD4310_DEBUG_UART_INST, (uint8_t)value);
}

static void debug_write_u32(uint32_t value)
{
    char digits[10];
    uint8_t count = 0;

    do {
        digits[count++] = (char)('0' + value % 10U);
        value /= 10U;
    } while (value != 0U);

    while (count > 0U) {
        debug_write_char(digits[--count]);
    }
}

static void debug_write_i32(int32_t value)
{
    uint32_t magnitude;

    if (value < 0) {
        debug_write_char('-');
        magnitude = (uint32_t)(-(value + 1)) + 1U;
    } else {
        magnitude = (uint32_t)value;
    }
    debug_write_u32(magnitude);
}

static void debug_write_fixed(float value, uint8_t decimals)
{
    uint32_t scale = 1U;
    uint32_t scaled;

    for (uint8_t i = 0; i < decimals; i++) {
        scale *= 10U;
    }

    if (value < 0.0f) {
        debug_write_char('-');
        value = -value;
    }
    scaled = (uint32_t)(value * (float)scale + 0.5f);
    debug_write_u32(scaled / scale);

    if (decimals > 0U) {
        uint32_t fraction = scaled % scale;
        uint32_t divisor = scale / 10U;

        debug_write_char('.');
        while (divisor > 0U) {
            debug_write_char((char)('0' + (fraction / divisor) % 10U));
            divisor /= 10U;
        }
    }
}

static float clamp_float(float value, float min_value, float max_value)
{
    if (value < min_value) return min_value;
    if (value > max_value) return max_value;
    return value;
}

static int16_t float_to_signed_raw(float value, float full_scale)
{
    float scaled;

    value = clamp_float(value, -full_scale, full_scale);
    scaled = value * QD4310_SIGNED_FS / full_scale;
    scaled += (scaled >= 0.0f) ? 0.5f : -0.5f;
    return (int16_t)scaled;
}

static uint16_t angle_to_raw(float angle_rad)
{
    float scaled;

    angle_rad = clamp_float(angle_rad, 0.0f, QD4310_TWO_PI);
    scaled = angle_rad * QD4310_UNSIGNED_FS / QD4310_TWO_PI + 0.5f;
    return (uint16_t)scaled;
}

static void drain_rx(void)
{
    uint8_t discard;
    while (DL_UART_Main_receiveDataCheck(QD4310_UART_INST, &discard)) {
    }
}

static void decode_feedback(const uint8_t *rx, QD4310_Feedback *feedback)
{
    QD4310_Feedback parsed;

    parsed.id       = rx[0];
    parsed.status   = rx[1];
    parsed.reserved = rx[2];
    parsed.current_raw = (int16_t)((uint16_t)rx[3] |
                                   ((uint16_t)rx[4] << 8));
    parsed.speed_raw = (int16_t)((uint16_t)rx[5] |
                                 ((uint16_t)rx[6] << 8));
    parsed.angle_raw = (uint16_t)rx[7] | ((uint16_t)rx[8] << 8);

    parsed.current_a = (float)parsed.current_raw * QD4310_CURRENT_FS_A /
                       QD4310_SIGNED_FS;
    parsed.speed_rpm = (float)parsed.speed_raw * QD4310_SPEED_FS_RPM /
                       QD4310_SIGNED_FS;
    parsed.angle_rad = (float)parsed.angle_raw * QD4310_TWO_PI /
                       QD4310_UNSIGNED_FS;

    *feedback = parsed;
}

void QD4310_Init(uint8_t device_id)
{
    s_device_id = device_id;
    s_timeout_ms = QD4310_RX_TIMEOUT_MS;
    s_busy = 0;
    drain_rx();
}

void QD4310_SetDeviceID(uint8_t device_id)
{
    s_device_id = device_id;
}

uint8_t QD4310_GetDeviceID(void)
{
    return s_device_id;
}

void QD4310_SetTimeout(uint32_t timeout_ms)
{
    if (timeout_ms > 0U) {
        s_timeout_ms = timeout_ms;
    }
}

uint32_t QD4310_GetTimeout(void)
{
    return s_timeout_ms;
}

void QD4310_DebugWrite(const uint8_t *data, uint32_t length)
{
    if (data == NULL) {
        return;
    }

    for (uint32_t i = 0; i < length; i++) {
        DL_UART_Main_transmitDataBlocking(QD4310_DEBUG_UART_INST, data[i]);
    }
}

void QD4310_DebugPrint(const char *text)
{
    if (text == NULL) {
        return;
    }

    while (*text != '\0') {
        debug_write_char(*text++);
    }
}

void QD4310_DebugPrintResult(QD4310_Result result)
{
    static const char *const names[] = {
        "OK", "INVALID_ARGUMENT", "BUSY", "TIMEOUT",
        "ID_MISMATCH", "CRC_ERROR", "UART_ERROR"
    };

    QD4310_DebugPrint("QD4310 result: ");
    if ((uint32_t)result < (sizeof(names) / sizeof(names[0]))) {
        QD4310_DebugPrint(names[result]);
    } else {
        QD4310_DebugPrint("UNKNOWN");
    }
    QD4310_DebugPrint("\r\n");
}

void QD4310_DebugPrintFeedback(const QD4310_Feedback *feedback)
{
    if (feedback == NULL) {
        QD4310_DebugPrint("QD4310 feedback: NULL\r\n");
        return;
    }

    QD4310_DebugPrint("QD4310 id=");
    debug_write_u32(feedback->id);
    QD4310_DebugPrint(" status=");
    debug_write_u32(feedback->status);
    QD4310_DebugPrint(" current=");
    debug_write_fixed(feedback->current_a, 3U);
    QD4310_DebugPrint("A speed=");
    debug_write_fixed(feedback->speed_rpm, 1U);
    QD4310_DebugPrint("rpm angle=");
    debug_write_fixed(feedback->angle_rad, 4U);
    QD4310_DebugPrint("rad raw(I/S/A)=");
    debug_write_i32(feedback->current_raw);
    debug_write_char('/');
    debug_write_i32(feedback->speed_raw);
    debug_write_char('/');
    debug_write_u32(feedback->angle_raw);
    QD4310_DebugPrint("\r\n");
}

uint8_t QD4310_CRC8(const uint8_t *data, uint32_t length)
{
    uint8_t crc = 0;

    if (data == NULL && length != 0U) {
        return 0;
    }

    for (uint32_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8U; bit++) {
            crc = (crc & 0x80U) ? (uint8_t)((crc << 1) ^ 0x07U)
                                : (uint8_t)(crc << 1);
        }
    }
    return crc;
}

QD4310_Result QD4310_Transfer(QD4310_Command command,
                              uint16_t value_raw,
                              QD4310_Feedback *feedback)
{
    uint8_t tx[QD4310_CONTROL_SIZE];
    uint8_t rx[QD4310_FEEDBACK_SIZE];
    uint32_t start;
    uint8_t rx_count = 0;
    QD4310_Result result = QD4310_RESULT_OK;

    if (feedback == NULL) {
        return QD4310_RESULT_INVALID_ARGUMENT;
    }
    if (s_busy) {
        return QD4310_RESULT_BUSY;
    }
    s_busy = 1;

    tx[0] = s_device_id;
    tx[1] = (uint8_t)command;
    tx[2] = (uint8_t)(value_raw & 0xFFU);
    tx[3] = (uint8_t)(value_raw >> 8);
    tx[4] = QD4310_CRC8(tx, QD4310_CONTROL_SIZE - 1U);

    drain_rx();
    for (uint8_t i = 0; i < QD4310_CONTROL_SIZE; i++) {
        DL_UART_Main_transmitDataBlocking(QD4310_UART_INST, tx[i]);
    }
    while (DL_UART_Main_isBusy(QD4310_UART_INST)) {
    }

    start = Delay_GetTick();
    while (rx_count < QD4310_FEEDBACK_SIZE) {
        if (DL_UART_Main_receiveDataCheck(QD4310_UART_INST, &rx[rx_count])) {
            rx_count++;
        } else if ((uint32_t)(Delay_GetTick() - start) >= s_timeout_ms) {
            result = QD4310_RESULT_TIMEOUT;
            goto finish;
        }
    }

    if (rx[0] != s_device_id) {
        result = QD4310_RESULT_ID_MISMATCH;
        goto finish;
    }
    if (QD4310_CRC8(rx, QD4310_FEEDBACK_SIZE - 1U) !=
        rx[QD4310_FEEDBACK_SIZE - 1U]) {
        result = QD4310_RESULT_CRC_ERROR;
        goto finish;
    }

    decode_feedback(rx, feedback);

finish:
    if (result != QD4310_RESULT_OK) {
        drain_rx();
    }
    s_busy = 0;
    return result;
}

QD4310_Result QD4310_Nop(QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_NOP, 0U, feedback);
}

QD4310_Result QD4310_Enable(QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_ENABLE, 0U, feedback);
}

QD4310_Result QD4310_Disable(QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_DISABLE, 0U, feedback);
}

QD4310_Result QD4310_SetCurrent(float current_a, QD4310_Feedback *feedback)
{
    int16_t raw = float_to_signed_raw(current_a, QD4310_CURRENT_FS_A);
    return QD4310_Transfer(QD4310_CMD_CURRENT, (uint16_t)raw, feedback);
}

QD4310_Result QD4310_SetSpeed(float speed_rpm, QD4310_Feedback *feedback)
{
    int16_t raw = float_to_signed_raw(speed_rpm, QD4310_SPEED_FS_RPM);
    return QD4310_Transfer(QD4310_CMD_SPEED, (uint16_t)raw, feedback);
}

QD4310_Result QD4310_SetAngle(float angle_rad, QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_ANGLE, angle_to_raw(angle_rad), feedback);
}

QD4310_Result QD4310_SetLowSpeed(float speed_rpm, QD4310_Feedback *feedback)
{
    int16_t raw = float_to_signed_raw(speed_rpm, QD4310_SPEED_FS_RPM);
    return QD4310_Transfer(QD4310_CMD_LOW_SPEED, (uint16_t)raw, feedback);
}

QD4310_Result QD4310_SetStepAngle(float delta_rad, QD4310_Feedback *feedback)
{
    int16_t raw = float_to_signed_raw(delta_rad, QD4310_TWO_PI);
    return QD4310_Transfer(QD4310_CMD_STEP_ANGLE, (uint16_t)raw, feedback);
}

QD4310_Result QD4310_Reboot(QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_REBOOT, 0U, feedback);
}

QD4310_Result QD4310_SetZero(QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_ZERO, 0U, feedback);
}

QD4310_Result QD4310_ClearError(QD4310_Feedback *feedback)
{
    return QD4310_Transfer(QD4310_CMD_CLEAR_ERROR, 0U, feedback);
}

uint8_t QD4310_IsEnabled(const QD4310_Feedback *feedback)
{
    if (feedback == NULL) return 0;
    return feedback->status & 0x01U;
}

uint8_t QD4310_GetMode(const QD4310_Feedback *feedback)
{
    if (feedback == NULL) return 0;
    return (feedback->status >> 4) & 0x0FU;
}
