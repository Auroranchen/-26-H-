/*
 * ========================== bmi088.h ==========================
 *  简介：
 *      Bosch BMI088 六轴 IMU(三轴加速度 + 三轴陀螺)SPI 驱动 + 姿态解算。
 *      BMI088 内部其实是【两颗独立的 SPI 从机】：加速度计子芯片、陀螺仪子芯片,
 *      两者共用 SCLK/MOSI/MISO, 但各自有一个片选(CS)。
 *
 *      本驱动做三件事：
 *          1. 用 SPI_0 读写 BMI088 两颗子芯片的寄存器(含加速度计 SPI 的“空字节”怪癖);
 *          2. 初始化: 软复位 / 上电 / 设量程与输出速率;
 *          3. 姿态解算: 读原始 accel+gyro, 用【互补滤波】算出 Pitch/Roll,
 *             Yaw 仅靠陀螺积分(无磁力计, 会缓慢漂移)。
 *
 *  为什么是精简移植：
 *      参考工程用的是 Bosch 官方 SensorAPI(上万行), 且只读原始数据、不算姿态。
 *      这里只保留“读原始六轴 + 姿态解算”这条最短路径, 代码量小、易维护。
 *
 *  硬件接线 (MSPM0G3507, SysConfig 已配 SPI_0)：
 *      SCLK      -> GPIOA.12   (SPI0_SCLK)
 *      MOSI/PICO -> GPIOA.9    (SPI0_PICO, 接模块 SDI/SDA)
 *      MISO/POCI -> GPIOA.13   (SPI0_POCI, 接模块 SDO/SAO)
 *      CS1(加速度)-> GPIOB.12   (SysConfig 引脚组 BMI088_CS 的 CS1, 软件片选)
 *      CS2(陀螺) -> GPIOB.13   (SysConfig 引脚组 BMI088_CS 的 CS2, 软件片选)
 *      VCC -> 3.3V     GND -> GND
 *      注意: 两颗子芯片必须各接一个 CS, 不能都接地, 否则总线冲突、无法分别寻址。
 *
 *  使用方法：
 *      1. 包含头文件：
 *              #include "bmi088.h"
 *
 *      2. 上电后先芯片初始化(含 1ms 节拍), 再初始化 IMU：
 *              SYSCFG_DL_init();
 *              Delay_TimerStart();     // 姿态解算的 dt 依赖 1ms 节拍
 *              BMI088_Init();          // 复位/上电/配置两颗子芯片
 *
 *      3. 主循环里【尽量频繁】调用 Update(内部按真实 dt 积分),
 *         需要显示/使用时再取姿态角：
 *              while (1) {
 *                  BMI088_Update();            // 读六轴 + 互补滤波(非阻塞)
 *                  BMI088_ShowOnOLED(0, 0);    // 显示 Yaw/Pitch/Roll
 *                  OLED_Refresh();
 *              }
 *
 *  依赖：
 *      - delay.h / delay.c   (初始化固定等待 + 1ms 节拍求 dt)
 *      - oled.h              (BMI088_ShowOnOLED 用到)
 *      - SPI_0 (SysConfig)   + 引脚组 BMI088_CS (两个软件片选)
 *      - <math.h>            (atan2f/sqrtf, Cortex-M0+ 无硬件 FPU, 为软件浮点)
 *
 *  提示：
 *      - 姿态角的正负方向取决于模块的实际安装朝向, 若方向相反,
 *        把对应轴的原始值或角速度取反即可(见 bmi088.c 中的解算处注释)。
 * ===============================================================
 */
#ifndef BMI088_H
#define BMI088_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 解算后的姿态角(单位: 度) */
typedef struct {
    float yaw;      /* 航向, 仅陀螺积分(无磁力计, 会漂移) */
    float pitch;    /* 俯仰 -90 ~ +90 */
    float roll;     /* 横滚 -180 ~ +180 */
} BMI088_Attitude_t;

/*
 * BMI088_Init        - 复位/上电/配置加速度计与陀螺仪。
 *                      返回 1=成功(两颗子芯片 ID 均正确), 0=失败(接线/供电/CS 问题)
 * BMI088_Update      - 读一次原始六轴数据并做互补滤波更新姿态(主循环频繁调用)
 * BMI088_GetAttitude - 取出最新姿态角(拷贝到 out)
 * BMI088_ShowOnOLED  - 把最新姿态角(带正负号/两位小数)显示到 OLED,
 *                      (x,y) 为第一行左上角, 16 号字往下排三行
 */
uint8_t BMI088_Init(void);
void    BMI088_Update(void);
void    BMI088_GetAttitude(BMI088_Attitude_t *out);
void    BMI088_ShowOnOLED(uint8_t x, uint8_t y);

#ifdef __cplusplus
}
#endif

#endif /* BMI088_H */
