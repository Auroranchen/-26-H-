/*
 * ========================== control.h ==========================
 *  简介：
 *      纯灰度循迹控制环(适用椭圆/圆弧轨道, 无直角转弯)。跑在
 *      TIMG0(TIMER_TOMOR_G0) 的 1ms 中断里, 内部分频到 10ms 执行一次。
 *
 *  控制逻辑:
 *      - 读 8 路灰度 -> 低触发数增强的加权质心偏差
 *      - 在 0~1000 参考 PWM 域中做 PD 差速(Kp=20, Ki=0, Kd=6)
 *      - 左右轮命令按硬件 PWM 满量程转换后直接驱动
 *      - 编码器仅用于实时速度显示和累计里程, 不参与电机输出闭环
 *
 *  节拍:
 *      TIMG0 = 1ms 中断; 每 CTRL_DIV(=10) 次即 10ms 跑一次控制逻辑。
 *      编码器每 10ms 读一次脉冲数(测速显示 + 累计里程)。
 *
 *  参数整定(见 control.c 顶部):
 *      CTRL_BASE_SPEED  参考 PWM 域中的巡线基础速度(默认 235)
 *      CTRL_KP/KI/KD    循迹 PID 参数(Ki 默认关闭)
 *      CTRL_ADJUST_MAX  转向修正量上限
 *      CTRL_MIN_RATIO   内侧轮最低速度比例
 *
 *  依赖: gray.h  motor.h  ti_msp_dl_config.h(TIMG0)
 *
 *  使用方法：
 *      #include "control.h"
 *      SYSCFG_DL_init();
 *      Gray/Motor init;
 *      Control_Start();          // 启动 TIMG0 控制中断
 *      Control_Run();            // A15 按下 -> 开跑
 *      Control_Stop();           // B16 按下 -> 停车
 *      int32_t s = Control_GetSpeed(0); // OLED 显示速度(脉冲/10ms)
 *      int32_t o = Control_GetOdo();    // 累计里程(圈数门限)
 * ===============================================================
 */
#ifndef CONTROL_H
#define CONTROL_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    CONTROL_EVENT2_OFF = 0,
    CONTROL_EVENT2_WAIT_CLEAR,
    CONTROL_EVENT2_WAIT_ARM,
    CONTROL_EVENT2_WAIT_A,
    CONTROL_EVENT2_TAIL_DELAY,
    CONTROL_EVENT2_RIGHT_REVERSE,
    CONTROL_EVENT2_DONE
} ControlEvent2State;

typedef enum {
    CONTROL_EVENT2_STOP_NONE = 0,
    CONTROL_EVENT2_STOP_A_TAIL,
    CONTROL_EVENT2_STOP_MANUAL
} ControlEvent2StopReason;

/* EVENT2 由 8 路灰度识别返回 A 点，再按车长时间比例补偿到车尾。 */
void Control_RunEvent2(void);
ControlEvent2State Control_GetEvent2State(void);
ControlEvent2StopReason Control_GetEvent2StopReason(void);
uint32_t Control_GetEvent2FinishTick(void);
int32_t Control_GetEvent2StopOdo(void);
uint32_t Control_GetEvent2DetectMs(void);
uint16_t Control_GetEvent2TailDelayMs(void);

/* EVENT4 使用独立的参考速度/PID配置，避免改变其他任务的循迹参数。 */
void Control_RunEvent4(void);

/* EVENT5 与 EVENT4 使用完全相同的运动速度和 PID 参数。 */
void Control_RunEvent5(void);

/*
 * Control_Start - 启动控制定时器(TIMG0)中断, 控制环开始运转(但默认不跑车,
 *                 需 Control_Run 才驱动电机)。开机后调用一次。
 */
void Control_Start(void);

/*
 * Control_Run  - 允许控制(电机受控开跑), 并复位巡线状态
 * Control_Stop - 停止控制(电机立即停车)
 * Control_IsRunning - 当前是否在跑
 */
void    Control_Run(void);
void    Control_Stop(void);
uint8_t Control_IsRunning(void);

/*
 * Control_SetSpeedScale - 设置巡线基速的运行时缩放百分比(0~100)。
 *   100 = 正常巡线速度; 临近终点时上层调小(如 40)让车减速, 便于精确停车。
 *   Control_Run 会自动复位为 100。
 */
void    Control_SetSpeedScale(uint8_t percent);

/*
 * Control_GetError - 最近一次循迹偏差
 * Control_GetSpeed - 最近一个 10ms 周期某轮编码器脉冲数; id: 0=左 1=右
 */
float      Control_GetError(void);
int32_t    Control_GetSpeed(uint8_t id);

/*
 * Control_GetOdo   - 自上次 Control_Run(开跑)以来的累计里程(编码器脉冲数,
 *                    取左右两轮之和)。在 10ms 控制中断里累加, 一个脉冲都不漏,
 *                    供上层做"跑够一圈"的里程门限。Control_Run 会自动清零。
 * Control_ClearOdo - 手动清零累计里程(一般不用, Control_Run 已清)。
 */
int32_t    Control_GetOdo(void);
void       Control_ClearOdo(void);

#ifdef __cplusplus
}
#endif

#endif /* CONTROL_H */
