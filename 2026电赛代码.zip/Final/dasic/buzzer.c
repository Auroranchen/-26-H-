/*
 * =========================== buzzer.c ===========================
 *  有源蜂鸣器驱动实现 (低电平触发, GPIOA.14)。
 *  详细使用说明与接线见 buzzer.h 头部注释。
 *
 *  电平约定(低电平触发)：
 *      响 = 引脚拉低 (DL_GPIO_clearPins)
 *      停 = 引脚拉高 (DL_GPIO_setPins)
 * ===============================================================
 */
#include "buzzer.h"
#include "delay.h"

void Buzzer_On(void)
{
    /* 低电平触发: 拉低 -> 响 */
    DL_GPIO_clearPins(BUZZER_PORT, BUZZER_BUZZER_A14_PIN);
}

void Buzzer_Off(void)
{
    /* 拉高 -> 停 */
    DL_GPIO_setPins(BUZZER_PORT, BUZZER_BUZZER_A14_PIN);
}

void Buzzer_Toggle(void)
{
    DL_GPIO_togglePins(BUZZER_PORT, BUZZER_BUZZER_A14_PIN);
}

void Beep(uint32_t ms)
{
    Buzzer_On();
    Delay_Ms(ms);
    Buzzer_Off();
}
