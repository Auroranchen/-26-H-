/*
 * ============================ led.c ============================
 *  两个板载 LED 的驱动实现。
 *  详细使用说明见 led.h 头部注释。
 * ===============================================================
 */
#include "led.h"

/* 用一张表把每个 LED 的 GPIO 端口和引脚集中管理,
 * 以后加/改灯只需改这张表, 上层调用完全不变。 */
typedef struct {
    GPIO_Regs *port;
    uint32_t   pin;
} LED_Map;

static const LED_Map s_led[LED_COUNT] = {
    [LED1] = { LED_LED_A24_PORT, LED_LED_A24_PIN },   /* GPIOA.24 */
    [LED2] = { LED_LED_B19_PORT, LED_LED_B19_PIN },   /* GPIOB.19 */
};

/* 把「点亮」翻译成实际的引脚高低电平, 由 LED_ACTIVE_HIGH 决定 */
static inline void led_apply(LED_ID id, uint8_t light_on)
{
#if LED_ACTIVE_HIGH
    if (light_on) {
        DL_GPIO_setPins(s_led[id].port, s_led[id].pin);
    } else {
        DL_GPIO_clearPins(s_led[id].port, s_led[id].pin);
    }
#else
    if (light_on) {
        DL_GPIO_clearPins(s_led[id].port, s_led[id].pin);
    } else {
        DL_GPIO_setPins(s_led[id].port, s_led[id].pin);
    }
#endif
}

void LED_On(LED_ID id)
{
    if (id >= LED_COUNT) return;
    led_apply(id, 1);
}

void LED_Off(LED_ID id)
{
    if (id >= LED_COUNT) return;
    led_apply(id, 0);
}

void LED_Toggle(LED_ID id)
{
    if (id >= LED_COUNT) return;
    DL_GPIO_togglePins(s_led[id].port, s_led[id].pin);
}

void LED_Write(LED_ID id, uint8_t on)
{
    if (id >= LED_COUNT) return;
    led_apply(id, on ? 1 : 0);
}

void LED_AllOn(void)
{
    for (LED_ID i = LED1; i < LED_COUNT; i++) {
        led_apply(i, 1);
    }
}

void LED_AllOff(void)
{
    for (LED_ID i = LED1; i < LED_COUNT; i++) {
        led_apply(i, 0);
    }
}
