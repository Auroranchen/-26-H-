/*
 * =========================== motor.c ===========================
 *  双直流电机(TB6612)驱动 + 编码器计数实现。
 *  详细说明见 motor.h 头部注释。
 * ===============================================================
 */
#include "motor.h"

/* ---- 电机方向反转开关(实车标定用) ----
 * 左右轮常常镜像安装, 命令"正转"时物理转向相反, 导致直行时车打转/偏。
 * 若某个轮子转向反了, 把对应宏改成 1 即可(只改这里, 不动别处逻辑)。
 * 调试口诀:
 *   - 开机应直行却"原地打转/一开就偏" => 两轮反着转 => 只翻其中一个(先试 R)
 *   - 能直行但整体"往后退"          => 两轮都反 => 两个都翻成 1
 *   - 能直行且向前                   => 正确, 都保持 0 */
#define MOTOR_L_REVERSE     0
#define MOTOR_R_REVERSE     0

/* ---- 每个电机的资源映射表: PWM通道 + 两个方向脚 + 是否反向 ----
 * PWM 通道用 SysConfig 的比较通道索引(CCP0/CCP1);
 * 方向脚 in1/in2 决定正反转(TB6612 真值表)。 */
typedef struct {
    uint32_t   pwm_cc_idx;      /* DL_TIMER_CC_x_INDEX */
    GPIO_Regs *in1_port; uint32_t in1_pin;
    GPIO_Regs *in2_port; uint32_t in2_pin;
    uint8_t    reverse;         /* 1=方向反转 */
} Motor_Map;

static const Motor_Map s_motor[MOTOR_NUM] = {
    /* 左轮: PWMA=CCP0(A8), 方向 AIN1=B10 / AIN2=B5 */
    [MOTOR_L] = {
        GPIO_MOTOR_PWM_C0_IDX,
        TOMOR_CONTROL_PORT, TOMOR_CONTROL_AIN1_PIN,
        TOMOR_CONTROL_PORT, TOMOR_CONTROL_AIN2_PIN,
        MOTOR_L_REVERSE,
    },
    /* 右轮: PWMB=CCP1(B9), 方向 BIN1=B4 / BIN2=B3 */
    [MOTOR_R] = {
        GPIO_MOTOR_PWM_C1_IDX,
        TOMOR_CONTROL_PORT, TOMOR_CONTROL_BIN1_PIN,
        TOMOR_CONTROL_PORT, TOMOR_CONTROL_BIN2_PIN,
        MOTOR_R_REVERSE,
    },
};

/* 编码器脉冲累加, 在 GROUP1 中断里 ++。
 * volatile: 主循环/控制中断读到的是中断里最新写入的值。 */
static volatile int32_t s_count[MOTOR_NUM] = {0};

/* ================= PWM / 方向 ================= */

static int32_t clamp_duty(int32_t duty)
{
    if (duty < 0)               return 0;
    if (duty > MOTOR_DUTY_MAX)  return MOTOR_DUTY_MAX;
    return duty;
}

void Motor_Init(void)
{
    /* 先把占空比写成 0%、方向置刹车(此时写比较寄存器不需要计数器已运行),
     * 再启动 PWM 计数器 —— 避免用 config 的初值(50%)先输出一段。 */
    Motor_StopAll();

    /* 启动 PWM 计数器(SysConfig 已配好通道/周期, 这里开始跑) */
    DL_Timer_startCounter(MOTOR_PWM_INST);

    /* 使能编码器所在两个端口的 GPIO 中断到 NVIC。
     * 两个端口都归 GROUP1, 使能其一即可触发 GROUP1_IRQHandler;
     * 两个都使能更稳妥。 */
    NVIC_EnableIRQ(GPIO_MULTIPLE_GPIOA_INT_IRQN);
    NVIC_EnableIRQ(GPIO_MULTIPLE_GPIOB_INT_IRQN);
}

void Motor_SetDuty(Motor_ID id, int32_t duty)
{
    if (id >= MOTOR_NUM) return;
    int32_t d = clamp_duty(duty);
    /* 本板 PWM 反相: 比较值越大, 实际驱动占空比越小(电机越慢)。
     * 真实占空比 = (period - 比较值)/period。
     * 为让上层 duty 保持"越大越快"的直觉, 这里做一次反相:
     *   比较值 = 满量程 - 期望 duty
     * 于是 duty=0 -> 比较值=MAX -> 0% -> 停; duty=MAX -> 比较值=0 -> 100% -> 全速。 */
    uint32_t cmp = (uint32_t)(MOTOR_DUTY_MAX - d);
    DL_Timer_setCaptureCompareValue(MOTOR_PWM_INST, cmp, s_motor[id].pwm_cc_idx);
}

/* dir: 0=停(两脚都拉低,滑行/刹车) 1=正转 2=反转
 * TB6612: in1=1,in2=0 -> 正; in1=0,in2=1 -> 反; 同=停
 * 若该电机标了 reverse, 则把正/反对调(实现方向反转)。 */
void Motor_SetDir(Motor_ID id, uint8_t dir)
{
    if (id >= MOTOR_NUM) return;
    const Motor_Map *m = &s_motor[id];

    /* 反向标志: 把 1<->2 对调 */
    if (m->reverse) {
        if (dir == 1)      dir = 2;
        else if (dir == 2) dir = 1;
    }

    if (dir == 1) {                 /* 正转 */
        DL_GPIO_setPins(m->in1_port, m->in1_pin);
        DL_GPIO_clearPins(m->in2_port, m->in2_pin);
    } else if (dir == 2) {          /* 反转 */
        DL_GPIO_clearPins(m->in1_port, m->in1_pin);
        DL_GPIO_setPins(m->in2_port, m->in2_pin);
    } else {                        /* 停 */
        DL_GPIO_clearPins(m->in1_port, m->in1_pin);
        DL_GPIO_clearPins(m->in2_port, m->in2_pin);
    }
}

void Motor_Drive(Motor_ID id, int32_t duty)
{
    if (id >= MOTOR_NUM) return;
    if (duty > 0) {
        Motor_SetDir(id, 1);
        Motor_SetDuty(id, duty);
    } else if (duty < 0) {
        Motor_SetDir(id, 2);
        Motor_SetDuty(id, -duty);
    } else {
        Motor_Stop(id);
    }
}

void Motor_Stop(Motor_ID id)
{
    if (id >= MOTOR_NUM) return;
    Motor_SetDuty(id, 0);
    Motor_SetDir(id, 0);
}

void Motor_StopAll(void)
{
    for (Motor_ID i = MOTOR_L; i < MOTOR_NUM; i++) {
        Motor_Stop(i);
    }
}
 void Motor_Brake(Motor_ID id)
  {
      if (id >= MOTOR_NUM) return;
      const Motor_Map *m = &s_motor[id];
      Motor_SetDuty(id, 0);
      /* TB6612: IN1=1, IN2=1 → 电机两端短接，产生制动转矩 */
      DL_GPIO_setPins(m->in1_port, m->in1_pin);
      DL_GPIO_setPins(m->in2_port, m->in2_pin);
  }

  void Motor_BrakeAll(void)
  {
      for (Motor_ID i = MOTOR_L; i < MOTOR_NUM; i++) {
          Motor_Brake(i);
      }
  }

/* ================= 编码器计数 ================= */

int32_t Motor_GetCount(Motor_ID id)
{
    if (id >= MOTOR_NUM) return 0;
    return s_count[id];
}

void Motor_ClearCount(Motor_ID id)
{
    if (id >= MOTOR_NUM) return;
    s_count[id] = 0;
}

/*
 * GROUP1_IRQHandler - GPIOA/GPIOB 共用的边沿中断入口。
 *   本项目里挂在 GROUP1 的有: 编码器 4 相 + 4 个按键, 全部使能了中断。
 *   DL_GPIO_getPendingInterrupt 每次只返回并清除"一个"pending 位,
 *   所以必须用 while 循环把该端口所有 pending 读干净, 否则:
 *     - 按键的 pending 可能"抢"在编码器前面被读走 -> 编码器漏计
 *     - 一次中断里多个引脚同时触发时会漏掉后面的
 *   这里只对编码器 A 相计数; 按键的 pending 读掉即可(按键靠主循环轮询)。
 *
 *   通道对应:
 *     左轮 A 相 = E1A = B18 (GPIOB, DIO18)
 *     右轮 A 相 = E2A = A26 (GPIOA, DIO26)
 */
void GROUP1_IRQHandler(void)
{
    uint32_t iidx;

    /* --- GPIOB: 排空所有 pending, 只对左轮 A 相(E1A/B18)计数 --- */
    while ((iidx = DL_GPIO_getPendingInterrupt(GPIOB)) != 0) {
        if (iidx == TOMOR_FEEDBACK_E1A_IIDX) {
            s_count[MOTOR_L]++;
        }
        /* 其它(按键/E2B)读掉即清, 不处理 */
    }

    /* --- GPIOA: 排空所有 pending, 只对右轮 A 相(E2A/A26)计数 --- */
    while ((iidx = DL_GPIO_getPendingInterrupt(GPIOA)) != 0) {
        if (iidx == TOMOR_FEEDBACK_E2A_IIDX) {
            s_count[MOTOR_R]++;
        }
        /* 其它(按键/E1B)读掉即清, 不处理 */
    }
}
