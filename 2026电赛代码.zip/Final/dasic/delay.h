/*
 * =========================== delay.h ===========================
 *  简介：
 *      本文件提供两类延时/计时, 按需选用：
 *
 *      【1. CPU 死等延时】Delay_Us / Delay_Ms / Delay_S
 *          - 靠 CPU 空跑指令计时, 不用定时器/中断。
 *          - 简单直接, 但延时期间 CPU 什么都做不了(阻塞)。
 *          - 主频由 SysConfig 的 CPUCLK_FREQ 决定(本板 = 80MHz)。
 *
 *      【2. TIMER_1 系统节拍】Delay_TimerStart / Delay_GetTick / Delay_TimerMs
 *          - 用 SysConfig 里配好的定时器 TIMER_1(TIMA1), 每 1ms 中断一次,
 *            后台自动累加一个毫秒计数, 不占用主循环。
 *          - Delay_GetTick() 拿到开机至今的毫秒数, 可做“非阻塞”定时:
 *            记下起始 tick, 主循环里判断是否够时间, 不卡住其它任务。
 *          - 精度比死等更稳(由硬件定时器保证)。
 *
 *  硬件(由 SysConfig 配置, 无需改动)：
 *      TIMER_1 = TIMA1, 时钟 80MHz/8/100 = 100kHz, 周期 100 计数 = 1ms,
 *      周期模式, 已使能零事件中断。
 *
 *  使用方法：
 *      1. 包含头文件：
 *              #include "delay.h"
 *
 *      2. 死等延时(在 SYSCFG_DL_init() 之后即可用)：
 *              Delay_Ms(500);      // 阻塞 500 毫秒
 *              Delay_Us(100);      // 阻塞 100 微秒
 *              Delay_S(2);         // 阻塞 2 秒
 *
 *      3. 定时器节拍(需先启动一次)：
 *              SYSCFG_DL_init();
 *              Delay_TimerStart();             // 打开定时器中断, 开始计时
 *
 *          阻塞版(精度更好的毫秒延时)：
 *              Delay_TimerMs(1000);            // 靠节拍延时 1 秒
 *
 *          非阻塞版(推荐, 主循环不被卡住)：
 *              uint32_t t = Delay_GetTick();   // 记录起点
 *              // ... 做别的事 ...
 *              if (Delay_GetTick() - t >= 1000) {  // 到 1 秒了吗
 *                  t = Delay_GetTick();        // 到了, 重新计时
 *                  // 执行每秒任务
 *              }
 *
 *  注意：
 *      - 死等延时精度为近似值, 做流水灯/消抖足够。
 *      - 定时器节拍需调用 Delay_TimerStart() 后才会走动。
 *      - g_tick_ms 到约 49.7 天会自然回绕, 用“无符号相减”比较不受影响。
 * ===============================================================
 */
#ifndef DELAY_H
#define DELAY_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- CPU 死等延时 ---- */
/*
 * Delay_Us - 阻塞延时指定微秒数
 * Delay_Ms - 阻塞延时指定毫秒数
 * Delay_S  - 阻塞延时指定秒数
 */
void Delay_Us(uint32_t us);
void Delay_Ms(uint32_t ms);
void Delay_S(uint32_t s);

/* ---- TIMER_1 1ms 系统节拍 ---- */
/*
 * Delay_TimerStart - 打开 TIMER_1 中断, 开始 1ms 计时(开机后调用一次)
 * Delay_GetTick    - 返回开机至今的毫秒数(用于非阻塞定时)
 * Delay_TimerMs    - 基于节拍的阻塞毫秒延时(精度比 Delay_Ms 稳)
 */
void     Delay_TimerStart(void);
uint32_t Delay_GetTick(void);
void     Delay_TimerMs(uint32_t ms);

#ifdef __cplusplus
}
#endif

#endif /* DELAY_H */
