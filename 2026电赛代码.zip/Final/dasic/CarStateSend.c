/*
 * ======================= CarStateSend.c =======================
 *  USART2 发送运动状态与摆球模式报文。说明见 CarStateSend.h。
 * ==============================================================
 */
#include "CarStateSend.h"
#include "ti_msp_dl_config.h"

/* 协议: 0x5A [state] [modenum] [checksum] 0xA5, checksum = state ^ modenum */
#define CARSTATE_SEND_FRAME_LEN  5U
#define CARSTATE_SEND_HEAD       0x5AU
#define CARSTATE_SEND_TAIL       0xA5U
#define CARSTATE_SEND_UART_INST  UART_2_INST

void CarStateSend_Init(void)
{
    /* UART2 已由 SYSCFG_DL_init() 初始化。 */
}

bool CarStateSend_Send(uint8_t state, uint8_t mode)
{
    uint8_t frame[CARSTATE_SEND_FRAME_LEN];
    uint8_t i;

    if (state > 4U || mode > 4U) {
        return false;
    }

    frame[0] = CARSTATE_SEND_HEAD;
    frame[1] = (uint8_t)state;
    frame[2] = mode;
    frame[3] = (uint8_t)(frame[1] ^ frame[2]);
    frame[4] = CARSTATE_SEND_TAIL;

    for (i = 0U; i < CARSTATE_SEND_FRAME_LEN; i++) {
        DL_UART_Main_transmitDataBlocking(CARSTATE_SEND_UART_INST, frame[i]);
    }
    while (DL_UART_Main_isBusy(CARSTATE_SEND_UART_INST)) {
    }

    return true;
}
