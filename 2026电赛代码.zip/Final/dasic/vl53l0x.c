/*
 * ========================== vl53l0x.c ==========================
 *  VL53L0X 激光测距传感器 I2C 驱动实现。
 *  详细协议、接线与用法见 vl53l0x.h 头部注释。
 *
 *  实现要点：
 *      - 使用 SysConfig 的 I2C0 (实例名 Steering) 做硬件 I2C。
 *      - XSHUT (VL53L0_EN / PB8) 软件复位：低电平掉电，高电平上电。
 *      - 初始化序列参考 ST 推荐 + 精简移植(SPAD/调谐/限值等关键寄存器)。
 *      - 连续测距模式下读 RESULT_RANGE_STATUS 等待就绪再取距离。
 * ===============================================================
 */
#include "vl53l0x.h"
#include "delay.h"

/* ---- 寄存器地址(ST 数据手册) ---- */
#define REG_IDENTIFICATION_MODEL_ID         0xC0
#define REG_IDENTIFICATION_REVISION_ID      0xC2
#define REG_SYSRANGE_START                  0x00
#define REG_SYSTEM_THRESH_HIGH              0x0C
#define REG_SYSTEM_THRESH_LOW               0x0E
#define REG_SYSTEM_SEQUENCE_CONFIG          0x01
#define REG_SYSTEM_RANGE_CONFIG             0x09
#define REG_SYSTEM_INTERMEASUREMENT_PERIOD  0x04
#define REG_SYSTEM_INTERRUPT_CONFIG_GPIO    0x0A
#define REG_SYSTEM_INTERRUPT_CLEAR          0x0B
#define REG_RESULT_INTERRUPT_STATUS         0x13
#define REG_RESULT_RANGE_STATUS             0x14
#define REG_RESULT_CORE_AMBIENT_WINDOW_EVENTS_RTN 0xBC
#define REG_RESULT_CORE_RANGING_TOTAL_EVENTS_RTN  0xC0
#define REG_RESULT_CORE_SIGNAL_RATE_RTN     0xCF
#define REG_FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT 0x44
#define REG_PRE_RANGE_CONFIG_VCSEL_PERIOD   0x50
#define REG_PRE_RANGE_CONFIG_TIMEOUT_MACROP_HI 0x51
#define REG_FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI 0x71
#define REG_MSRC_CONFIG_CONTROL             0x60
#define REG_GLOBAL_CONFIG_SPAD_ENABLES_REF_0 0xB0
#define REG_GLOBAL_CONFIG_REF_EN_START_SELECT 0xB6
#define REG_DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD 0x4E
#define REG_DYNAMIC_SPAD_REF_START_OFFSET   0x4F
#define REG_VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV 0x89
#define REG_ALGO_PHASECAL_LIM               0x30
#define REG_ALGO_PHASECAL_CONFIG_TIMEOUT    0x30
#define REG_GPIO_HV_MUX_ACTIVE_HIGH         0x84
#define REG_SYSTEM_SEQUENCE_CONFIG          0x01
#define REG_SOFT_RESET_GO2_SOFT_RESET_N     0xBF
#define REG_I2C_SLAVE_DEVICE_ADDRESS        0x8A

#define MODEL_ID_EXPECTED                   0xEE

/* XSHUT 控制宏 (SysConfig: GPIO 组 VL53L0_EN, 引脚 VL53L0_EN_PB8) */
#define XSHUT_LOW()   DL_GPIO_clearPins(VL53L0_EN_PORT, VL53L0_EN_VL53L0_EN_PB8_PIN)
#define XSHUT_HIGH()  DL_GPIO_setPins  (VL53L0_EN_PORT, VL53L0_EN_VL53L0_EN_PB8_PIN)

/* I2C 实例 (SysConfig 名 Steering = I2C0) */
#define VL53_I2C_INST   Steering_INST

/* ---- 内部状态 ---- */
static uint8_t  s_addr        = VL53L0X_I2C_ADDR;
static uint16_t s_timeout_ms  = 500;
static uint8_t  s_stop_var    = 0;   /* 连续测距停止变量(寄存器 0x91) */

/* ================================================================
 *  底层 I2C 读写 (与 OLED 驱动同一套 MSPM0 硬件 I2C API)
 * ================================================================ */

static void i2c_wait_idle(void)
{
    while (!(DL_I2C_getControllerStatus(VL53_I2C_INST) & DL_I2C_CONTROLLER_STATUS_IDLE)) {
        /* busy wait */
    }
}

/* 写 n 字节到寄存器(先发 reg, 再发 data[]) */
static uint8_t i2c_write_reg(uint8_t reg, const uint8_t *data, uint8_t len)
{
    uint8_t buf[17];
    if (len > 16) return 0;
    buf[0] = reg;
    for (uint8_t i = 0; i < len; i++) {
        buf[i + 1] = data[i];
    }

    i2c_wait_idle();
    DL_I2C_fillControllerTXFIFO(VL53_I2C_INST, buf, (uint16_t)(len + 1));
    DL_I2C_startControllerTransfer(VL53_I2C_INST, s_addr,
                                   DL_I2C_CONTROLLER_DIRECTION_TX, (uint16_t)(len + 1));
    /* 等待进入 BUSY 再等回 IDLE */
    while (!(DL_I2C_getControllerStatus(VL53_I2C_INST) & DL_I2C_CONTROLLER_STATUS_BUSY_BUS)) {
    }
    i2c_wait_idle();
    return 1;
}

/* 写单字节寄存器 */
static uint8_t write_reg(uint8_t reg, uint8_t val)
{
    return i2c_write_reg(reg, &val, 1);
}

/* 写 16 位寄存器(大端) */
static uint8_t write_reg16(uint8_t reg, uint16_t val)
{
    uint8_t buf[2] = { (uint8_t)(val >> 8), (uint8_t)(val & 0xFF) };
    return i2c_write_reg(reg, buf, 2);
}

/* 写 32 位寄存器(大端) */
static uint8_t write_reg32(uint8_t reg, uint32_t val)
{
    uint8_t buf[4] = {
        (uint8_t)(val >> 24), (uint8_t)(val >> 16),
        (uint8_t)(val >>  8), (uint8_t)(val)
    };
    return i2c_write_reg(reg, buf, 4);
}

/* 读 n 字节: 先发 reg(写), 再读 data */
static uint8_t i2c_read_reg(uint8_t reg, uint8_t *data, uint8_t len)
{
    /* 写寄存器地址 */
    i2c_wait_idle();
    DL_I2C_fillControllerTXFIFO(VL53_I2C_INST, &reg, 1);
    DL_I2C_startControllerTransfer(VL53_I2C_INST, s_addr,
                                   DL_I2C_CONTROLLER_DIRECTION_TX, 1);
    while (!(DL_I2C_getControllerStatus(VL53_I2C_INST) & DL_I2C_CONTROLLER_STATUS_BUSY_BUS)) {
    }
    i2c_wait_idle();

    /* 读数据 */
    i2c_wait_idle();
    DL_I2C_startControllerTransfer(VL53_I2C_INST, s_addr,
                                   DL_I2C_CONTROLLER_DIRECTION_RX, len);
    while (!(DL_I2C_getControllerStatus(VL53_I2C_INST) & DL_I2C_CONTROLLER_STATUS_BUSY_BUS)) {
    }

    for (uint8_t i = 0; i < len; i++) {
        while (DL_I2C_isControllerRXFIFOEmpty(VL53_I2C_INST)) {
            /* wait byte */
        }
        data[i] = DL_I2C_receiveControllerData(VL53_I2C_INST);
    }
    i2c_wait_idle();
    return 1;
}

static uint8_t read_reg(uint8_t reg)
{
    uint8_t v = 0;
    i2c_read_reg(reg, &v, 1);
    return v;
}

static uint16_t read_reg16(uint8_t reg)
{
    uint8_t b[2];
    i2c_read_reg(reg, b, 2);
    return ((uint16_t)b[0] << 8) | b[1];
}

/* ================================================================
 *  辅助: 超时与序列控制
 * ================================================================ */

static uint8_t check_timeout(uint32_t start_ms)
{
    return (Delay_GetTick() - start_ms) >= s_timeout_ms;
}

/* 启动一次测量序列(内部用) */
static uint8_t perform_single_ref_calibration(uint8_t vhv_init_byte)
{
    write_reg(REG_SYSRANGE_START, 0x01 | vhv_init_byte);
    uint32_t t0 = Delay_GetTick();
    while ((read_reg(REG_RESULT_INTERRUPT_STATUS) & 0x07) == 0) {
        if (check_timeout(t0)) return 0;
    }
    write_reg(REG_SYSTEM_INTERRUPT_CLEAR, 0x01);
    write_reg(REG_SYSRANGE_START, 0x00);
    return 1;
}

/* 设置测量序列步骤使能掩码 */
static void set_sequence_steps(uint8_t sequence)
{
    write_reg(REG_SYSTEM_SEQUENCE_CONFIG, sequence);
}

/* ================================================================
 *  对外接口
 * ================================================================ */

void VL53L0X_SetTimeout(uint16_t timeout_ms)
{
    s_timeout_ms = timeout_ms;
}

uint8_t VL53L0X_GetAddress(void)
{
    return s_addr;
}

void VL53L0X_SetAddress(uint8_t new_addr)
{
    /* 写新地址到传感器, 随后本驱动使用新地址通信 */
    write_reg(REG_I2C_SLAVE_DEVICE_ADDRESS, new_addr & 0x7F);
    s_addr = new_addr & 0x7F;
}

uint8_t VL53L0X_Init(void)
{
    /* 1. XSHUT 复位: 先拉低掉电, 再拉高上电 */
    XSHUT_LOW();
    Delay_Ms(10);
    XSHUT_HIGH();
    Delay_Ms(10);

    /* 2. 软复位 */
    write_reg(REG_SOFT_RESET_GO2_SOFT_RESET_N, 0x00);
    Delay_Ms(2);
    write_reg(REG_SOFT_RESET_GO2_SOFT_RESET_N, 0x01);
    Delay_Ms(5);

    /* 3. 读 Model ID, 应为 0xEE */
    uint8_t model_id = read_reg(REG_IDENTIFICATION_MODEL_ID);
    if (model_id != MODEL_ID_EXPECTED) {
        return 0;
    }

    /* 4. 2V8 模式(多数模块 IO 为 2.8V 逻辑, 写 0x01) */
    write_reg(REG_VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV,
              read_reg(REG_VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV) | 0x01);

    /* 5. 设置 I2C 标准模式 */
    write_reg(0x88, 0x00);

    write_reg(0x80, 0x01);
    write_reg(0xFF, 0x01);
    write_reg(0x00, 0x00);
    s_stop_var = read_reg(0x91);
    write_reg(0x00, 0x01);
    write_reg(0xFF, 0x00);
    write_reg(0x80, 0x00);

    /* 6. 禁用 MSRC / TCC / DSS 等, 简化序列 */
    write_reg(REG_MSRC_CONFIG_CONTROL, read_reg(REG_MSRC_CONFIG_CONTROL) | 0x12);

    /* 信号速率限值(默认 0.25 MCPS) */
    write_reg16(REG_FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT, 0x0020);

    /* 系统序列: 使能最终测距等基本步骤 */
    set_sequence_steps(0xFF);

    /* 7. 参考 SPAD 管理(简化: 读当前配置后写回) */
    write_reg(0xFF, 0x01);
    write_reg(REG_DYNAMIC_SPAD_REF_START_OFFSET, 0x00);
    write_reg(REG_DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD, 0x2C);
    write_reg(0xFF, 0x00);
    write_reg(REG_GLOBAL_CONFIG_REF_EN_START_SELECT, 0xB4);

    /* 使能参考 SPAD (默认全开简化) */
    uint8_t spad_map[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    write_reg(0xFF, 0x01);
    write_reg(0x4F, 0x00);
    write_reg(0x4E, 0x2C);
    write_reg(0xFF, 0x00);
    i2c_write_reg(REG_GLOBAL_CONFIG_SPAD_ENABLES_REF_0, spad_map, 6);

    /* 8. 加载默认调谐设置(ST 推荐精简集) */
    write_reg(0xFF, 0x01);
    write_reg(0x00, 0x00);
    write_reg(0xFF, 0x00);
    write_reg(0x09, 0x00);
    write_reg(0x10, 0x00);
    write_reg(0x11, 0x00);
    write_reg(0x24, 0x01);
    write_reg(0x25, 0xFF);
    write_reg(0x75, 0x00);
    write_reg(0xFF, 0x01);
    write_reg(0x4E, 0x2C);
    write_reg(0x48, 0x00);
    write_reg(0x30, 0x20);
    write_reg(0xFF, 0x00);
    write_reg(0x30, 0x09);
    write_reg(0x54, 0x00);
    write_reg(0x31, 0x04);
    write_reg(0x32, 0x03);
    write_reg(0x40, 0x83);
    write_reg(0x46, 0x25);
    write_reg(0x60, 0x00);
    write_reg(0x27, 0x00);
    write_reg(0x50, 0x06);
    write_reg(0x51, 0x00);
    write_reg(0x52, 0x96);
    write_reg(0x56, 0x08);
    write_reg(0x57, 0x30);
    write_reg(0x61, 0x00);
    write_reg(0x62, 0x00);
    write_reg(0x64, 0x00);
    write_reg(0x65, 0x00);
    write_reg(0x66, 0xA0);
    write_reg(0xFF, 0x01);
    write_reg(0x22, 0x32);
    write_reg(0x47, 0x14);
    write_reg(0x49, 0xFF);
    write_reg(0x4A, 0x00);
    write_reg(0xFF, 0x00);
    write_reg(0x7A, 0x0A);
    write_reg(0x7B, 0x00);
    write_reg(0x78, 0x21);
    write_reg(0xFF, 0x01);
    write_reg(0x23, 0x34);
    write_reg(0x42, 0x00);
    write_reg(0x44, 0xFF);
    write_reg(0x45, 0x26);
    write_reg(0x46, 0x05);
    write_reg(0x40, 0x40);
    write_reg(0x0E, 0x06);
    write_reg(0x20, 0x1A);
    write_reg(0x43, 0x40);
    write_reg(0xFF, 0x00);
    write_reg(0x34, 0x03);
    write_reg(0x35, 0x44);
    write_reg(0xFF, 0x01);
    write_reg(0x31, 0x04);
    write_reg(0x4B, 0x09);
    write_reg(0x4C, 0x05);
    write_reg(0x4D, 0x04);
    write_reg(0xFF, 0x00);
    write_reg(0x44, 0x00);
    write_reg(0x45, 0x20);
    write_reg(0x47, 0x08);
    write_reg(0x48, 0x28);
    write_reg(0x67, 0x00);
    write_reg(0x70, 0x04);
    write_reg(0x71, 0x01);
    write_reg(0x72, 0xFE);
    write_reg(0x76, 0x00);
    write_reg(0x77, 0x00);
    write_reg(0xFF, 0x01);
    write_reg(0x0D, 0x01);
    write_reg(0xFF, 0x00);
    write_reg(0x80, 0x01);
    write_reg(0x01, 0xF8);
    write_reg(0xFF, 0x01);
    write_reg(0x8E, 0x01);
    write_reg(0x00, 0x01);
    write_reg(0xFF, 0x00);
    write_reg(0x80, 0x00);

    /* 9. 中断配置: GPIO 新样本就绪 */
    write_reg(REG_SYSTEM_INTERRUPT_CONFIG_GPIO, 0x04);
    write_reg(REG_GPIO_HV_MUX_ACTIVE_HIGH,
              read_reg(REG_GPIO_HV_MUX_ACTIVE_HIGH) & ~0x10);
    write_reg(REG_SYSTEM_INTERRUPT_CLEAR, 0x01);

    /* 序列: TCC + MSRC + Pre + Final */
    set_sequence_steps(0xE8);

    /* 10. 参考校准 */
    if (!perform_single_ref_calibration(0x40)) return 0;  /* VHV */
    if (!perform_single_ref_calibration(0x00)) return 0;  /* Phase */

    /* 恢复完整序列 */
    set_sequence_steps(0xE8);

    return 1;
}

void VL53L0X_StartContinuous(uint32_t period_ms)
{
    write_reg(0x80, 0x01);
    write_reg(0xFF, 0x01);
    write_reg(0x00, 0x00);
    write_reg(0x91, s_stop_var);
    write_reg(0x00, 0x01);
    write_reg(0xFF, 0x00);
    write_reg(0x80, 0x00);

    if (period_ms != 0) {
        /* 有周期: 写 inter-measurement period (单位约 1.06ms 步进, 简化直接写) */
        uint16_t period = (uint16_t)period_ms;
        write_reg32(REG_SYSTEM_INTERMEASUREMENT_PERIOD, period);
        write_reg(REG_SYSRANGE_START, 0x04);   /* timed continuous */
    } else {
        write_reg(REG_SYSRANGE_START, 0x02);   /* back-to-back continuous */
    }
}

void VL53L0X_StopContinuous(void)
{
    write_reg(REG_SYSRANGE_START, 0x01);       /* stop */
    write_reg(0xFF, 0x01);
    write_reg(0x00, 0x00);
    write_reg(0x91, 0x00);
    write_reg(0x00, 0x01);
    write_reg(0xFF, 0x00);
}

uint16_t VL53L0X_ReadRangeContinuousMillimeters(void)
{
    uint32_t t0 = Delay_GetTick();

    /* 等待新数据就绪 (RESULT_INTERRUPT_STATUS bit0-2) */
    while ((read_reg(REG_RESULT_INTERRUPT_STATUS) & 0x07) == 0) {
        if (check_timeout(t0)) {
            return VL53L0X_RANGE_ERROR;
        }
    }

    /* 距离在 RESULT_RANGE_STATUS 起始偏移 +10 的 16 位(大端) */
    uint16_t range = read_reg16(REG_RESULT_RANGE_STATUS + 10);

    write_reg(REG_SYSTEM_INTERRUPT_CLEAR, 0x01);

    return range;
}
