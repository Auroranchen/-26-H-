/*
 * =========================== key.c ============================
 *  四个按键的轮询式驱动实现(消抖 + 单次按下事件)。
 *  详细说明见 key.h 头部注释。
 * ===============================================================
 */
#include "key.h"

/* 按键资源表 + 是否长按型 */
typedef struct {
    GPIO_Regs *port;
    uint32_t   pin;
    uint8_t    is_long;     /* 1=检测长按, 0=检测短按(松手触发) */
} Key_Map;

static const Key_Map s_key[KEY_EVENT_NUM] = {
    [KEY_START]        = { KEY_KEY_A15_PORT, KEY_KEY_A15_PIN, 0 },  /* PA15 启动 */
    [KEY_STOP]         = { KEY_KEY_B16_PORT, KEY_KEY_B16_PIN, 0 },  /* PB16 停止 */
    [KEY_MODE_NEXT]    = { KEY_KEY_A07_PORT, KEY_KEY_A07_PIN, 0 },  /* PA07 切换要求 */
    [KEY_MODE_CONFIRM] = { KEY_KEY_B14_PORT, KEY_KEY_B14_PIN, 0 },  /* PB14 确认要求 */
};

/* 每个按键的运行状态 */
static uint8_t  s_pressed[KEY_EVENT_NUM]   = {0};   /* 稳定的按下状态(消抖后) */
static uint16_t s_hold_ms[KEY_EVENT_NUM]   = {0};   /* 已按住时长 */
static uint8_t  s_long_fired[KEY_EVENT_NUM]= {0};   /* 长按事件本次是否已触发 */
static uint8_t  s_event[KEY_EVENT_NUM]     = {0};   /* 待读取的事件标志 */

/* 消抖阈值(毫秒): 稳定按下累计超过该时长即确认。取小值以求"按一下就响应"。
 * 主循环每 KEY_SCAN_MS 扫一次(建议已减到 5ms), 5~10ms 足够滤掉抖动。 */
#define KEY_DEBOUNCE_MS   5

/* 读某按键此刻是否被按下(上拉, 按下=低电平=读到0) */
static uint8_t key_is_down(Key_ID id)
{
    uint32_t level = DL_GPIO_readPins(s_key[id].port, s_key[id].pin);
    return (level & s_key[id].pin) ? 0 : 1;     /* 低电平=按下 */
}

void Key_Scan(uint16_t dt_ms)
{
    for (uint8_t i = 0; i < KEY_EVENT_NUM; i++) {
        uint8_t down = key_is_down(i);

        if (down) {
            if (s_hold_ms[i] < 0xFFFF - dt_ms) s_hold_ms[i] += dt_ms;

            /* 短按型: 按下稳定到消抖阈值的"那一刻"立即触发一次
             * (边沿触发: 靠 s_pressed 从0->1 只发一次, 按住不重复) */
            if (!s_pressed[i] && s_hold_ms[i] >= KEY_DEBOUNCE_MS) {
                s_pressed[i] = 1;               /* 确认按下 */
                if (!s_key[i].is_long) {
                    s_event[i] = 1;             /* 短按: 按下即产生事件 */
                }
            }

            /* 长按型: 按住够久且尚未触发 -> 产生一次长按事件 */
            if (s_key[i].is_long && s_pressed[i] &&
                !s_long_fired[i] && s_hold_ms[i] >= KEY_LONG_MS) {
                s_event[i]      = 1;
                s_long_fired[i] = 1;
            }
        } else {
            /* 松手: 复位状态, 准备下一次按下 */
            s_pressed[i]    = 0;
            s_hold_ms[i]    = 0;
            s_long_fired[i] = 0;
        }
    }
}

uint8_t Key_GetEvent(Key_ID id)
{
    if (id >= KEY_EVENT_NUM) return 0;
    uint8_t e = s_event[id];
    s_event[id] = 0;            /* 读取即清除 */
    return e;
}
